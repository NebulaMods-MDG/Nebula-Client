using GorillaNetworking;
using GorillaNetworking.Store;
using HarmonyLib;
using UnityEngine;

namespace MalachiTemp.Backend;

internal class Patches
{
	public class GameplayPatches
	{
		[HarmonyPatch(typeof(SlingshotProjectile), "CheckForAOEKnockback")]
		public class CheckForAOEKnockbackPatch
		{
			public static bool Fling = true;

			private static bool Prefix(Vector3 impactPosition, float impactSpeed)
			{
				return Fling;
			}
		}

		[HarmonyPatch(/*Could not decode attribute arguments.*/)]
		public class AntiTeleportTechnologyPatch
		{
			private static bool Prefix()
			{
				return false;
			}
		}

		[HarmonyPatch(/*Could not decode attribute arguments.*/)]
		public class CreatePrimitivePatch
		{
			public static void Postfix(GameObject __result)
			{
				if ((Object)(object)__result.GetComponent<Renderer>() != (Object)null)
				{
					__result.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
				}
			}
		}

		[HarmonyPatch(typeof(VRRig), "OnDisable")]
		public class OnDisablePatch
		{
			public static bool Prefix(VRRig __instance)
			{
				return !__instance.isLocal;
			}
		}

		[HarmonyPatch(typeof(VRRig), "Awake")]
		public class AwakePatch
		{
			public static bool Prefix(VRRig __instance)
			{
				return ((Object)((Component)__instance).gameObject).name != "Local Gorilla Player(Clone)";
			}
		}

		[HarmonyPatch(typeof(VRRig), "PostTick")]
		public class PostTickPatch
		{
			public static bool Prefix(VRRig __instance)
			{
				return !__instance.isLocal || ((Behaviour)__instance).enabled;
			}
		}

		[HarmonyPatch(typeof(PhotonNetworkController), "OnJoinedRoom")]
		public class JoinedRoomPatch
		{
			public static bool enabled;

			private static readonly FieldRef<PhotonNetworkController, JoinType> CurrentJoinTypeRef = AccessTools.FieldRefAccess<PhotonNetworkController, JoinType>("currentJoinType");

			private static void Prefix()
			{
				if (enabled)
				{
					PhotonNetworkController instance = PhotonNetworkController.Instance;
					if (!((Object)(object)instance == (Object)null))
					{
						CurrentJoinTypeRef.Invoke(instance) = (JoinType)6;
					}
				}
			}
		}
	}

	[HarmonyPatch(typeof(VRRig), "IsItemAllowed")]
	public class CosmeticPatch
	{
		public static bool enabled;

		public static void Postfix(VRRig __instance, ref bool __result)
		{
			if (enabled)
			{
				__result = true;
			}
		}
	}

	[HarmonyPatch(typeof(BundleManager), "CheckIfBundlesOwned")]
	public class PostGetData
	{
		public static bool CosmeticsInitialized;

		private static void Postfix()
		{
			CosmeticsInitialized = true;
			CosmeticsOwned = ((CosmeticsController)CosmeticsController.instance).concatStringCosmeticsAllowed;
		}
	}

	public static string CosmeticsOwned;
}
