using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using BepInEx;
using ExitGames.Client.Photon;
using GTAG_NotificationLib;
using GorillaExtensions;
using GorillaGameModes;
using GorillaLocomotion;
using GorillaNetworking;
using GorillaTagScripts;
using HarmonyLib;
using MalachiTemp.UI;
using MalachiTemp.Utilities;
using Photon.Pun;
using Photon.Realtime;
using PlayFab;
using PlayFab.Internal;
using UnityEngine;
using UnityEngine.InputSystem;
using dark.efijiPOIWikjek;

namespace MalachiTemp.Backend;

internal class Mods : MonoBehaviour
{
	public class HarmonyMod : BaseUnityPlugin
	{
		private void Start()
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_000c: Expected O, but got Unknown
			Harmony val = new Harmony("com.yourname.harmony");
			val.PatchAll();
		}
	}

	public static class ForceGrabMods
	{
		public static readonly FieldRef<TakeMyHand_HandLink, float> PrivateFloatRef = AccessTools.FieldRefAccess<TakeMyHand_HandLink, float>("rejectGrabsUntilTimestamp");

		private static float grabDelay = 0f;

		public static void ForceGrabGun()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			MakeGun(Color.cyan, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, (PrimitiveType)0, GTPlayer.Instance.RightHand.controllerTransform, liner: true, delegate
			{
				//IL_0065: Unknown result type (might be due to invalid IL or missing references)
				VRRig val = null;
				if ((Object)(object)((RaycastHit)(ref raycastHit)).collider != (Object)null)
				{
					val = ((Component)((RaycastHit)(ref raycastHit)).collider).GetComponentInParent<VRRig>();
				}
				if ((Object)(object)val == (Object)null)
				{
					Player playerFromGun = RigShit.GetPlayerFromGun();
					if (playerFromGun != null)
					{
						val = RigShit.GetVRRigFromPlayer(playerFromGun);
					}
				}
				if (!((Object)(object)val == (Object)null))
				{
					ForceGrabPlayer(val, ((Component)VRRig.LocalRig).transform.position);
				}
			}, delegate
			{
				((Behaviour)VRRig.LocalRig).enabled = true;
			});
		}

		public static bool ForceGrabPlayer(VRRig rig, Vector3 targetPosition, bool returnOnGrab = false)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_000d: Expected O, but got Unknown
			//IL_011f: Unknown result type (might be due to invalid IL or missing references)
			if ((Object)rig == (Object)null || rig.isLocal)
			{
				return false;
			}
			if (!rig.leftHandLink.CanBeGrabbed() && !rig.rightHandLink.CanBeGrabbed())
			{
				return false;
			}
			bool flag = rig.leftHandLink.CanBeGrabbed();
			TakeMyHand_HandLink val = (flag ? VRRig.LocalRig.leftHandLink : VRRig.LocalRig.rightHandLink);
			TakeMyHand_HandLink val2 = (flag ? rig.leftHandLink : rig.rightHandLink);
			if (val2.grabbedPlayer == NetworkSystem.Instance.LocalPlayer)
			{
				return returnOnGrab;
			}
			float num = PrivateFloatRef.Invoke(val2);
			if (grabDelay == 0f)
			{
				grabDelay = ((num > Time.time) ? num : (Time.time + 1f));
				return false;
			}
			if (Time.time <= grabDelay)
			{
				return false;
			}
			((Behaviour)VRRig.LocalRig).enabled = false;
			((Component)VRRig.LocalRig).transform.position = rig.syncPos;
			val.TentacleTryCreateLink(val2);
			((Behaviour)VRRig.LocalRig).enabled = true;
			grabDelay = ((num > Time.time) ? num : (Time.time + 1f));
			return false;
		}
	}

	public static class ElevatorMods
	{
		public static readonly FieldRef<GRElevatorManager, ElevatorLocation> CurrentLocationRef = AccessTools.FieldRefAccess<GRElevatorManager, ElevatorLocation>("currentLocation");

		private static readonly FieldRef<GRElevatorManager, ElevatorLocation> DestinationRef = AccessTools.FieldRefAccess<GRElevatorManager, ElevatorLocation>("destination");

		public static void ElevatorLagGun()
		{
			//IL_0026: Unknown result type (might be due to invalid IL or missing references)
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_004a: Unknown result type (might be due to invalid IL or missing references)
			if (!PhotonNetwork.IsMasterClient)
			{
				NotifiLib.SendNotification("[<color=red>ERROR]</color>: You must be Master Client to use this!");
				DisableButton("Lag Gun In Elevator (M)");
			}
			else
			{
				MakeGun(Color.red, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, (PrimitiveType)0, GTPlayer.Instance.RightHand.controllerTransform, liner: true, delegate
				{
					ElevatorLagMethod();
				}, delegate
				{
				});
			}
		}

		public static void LagAllInElevator()
		{
			if (!PhotonNetwork.IsMasterClient)
			{
				NotifiLib.SendNotification("[<color=red>ERROR]</color>: You must be Master Client to use this!");
				DisableButton("Lag All In Elevator (M)");
			}
			else
			{
				ElevatorLagMethod();
			}
		}

		public static void ElevatorLagMethod()
		{
			GRElevatorManager._instance.ActivateElevating();
		}

		public static void ElevatorKickMethod()
		{
			if (!PhotonNetwork.InRoom)
			{
				NotifiLib.SendNotification("[<color=red>ERROR]</color>: You are not in a room!");
				return;
			}
			if (NetworkSystem.Instance.SessionIsPrivate)
			{
				NotifiLib.SendNotification("[<color=red>ERROR]</color>: This cannot be used in private lobbies!");
				return;
			}
			if (!PhotonNetwork.IsMasterClient)
			{
				NotifiLib.SendNotification("[<color=red>ERROR]</color>: You must be Master Client to use this!");
				return;
			}
			GRElevatorManager instance = GRElevatorManager._instance;
			if (!((Object)(object)instance == (Object)null))
			{
				DestinationRef.Invoke(instance) = (ElevatorLocation)4;
				instance.ActivateElevating();
				KeepElevatorOpen();
				((MonoBehaviour)instance).StartCoroutine(resetdestinationfield());
			}
		}

		public static void ElevatorKickMethod2()
		{
			if (!PhotonNetwork.InRoom)
			{
				NotifiLib.SendNotification("[<color=red>ERROR]</color>: You are not in a room!");
				return;
			}
			if (NetworkSystem.Instance.SessionIsPrivate)
			{
				NotifiLib.SendNotification("[<color=red>ERROR]</color>: This cannot be used in private lobbies!");
				return;
			}
			if (!PhotonNetwork.IsMasterClient)
			{
				NotifiLib.SendNotification("[<color=red>ERROR]</color>: You must be Master Client to use this!");
				return;
			}
			GRElevatorManager instance = GRElevatorManager._instance;
			if (!((Object)(object)instance == (Object)null))
			{
				DestinationRef.Invoke(instance) = CurrentLocationRef.Invoke(instance);
				instance.ActivateElevating();
				KeepElevatorOpen();
				((MonoBehaviour)instance).StartCoroutine(resetdestinationfield());
			}
		}

		private static IEnumerator resetdestinationfield()
		{
			yield return (object)new WaitForSeconds(1f);
			ElevatorReset();
		}

		public static void ElevatorKickGun()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			MakeGun(Color.red, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, (PrimitiveType)0, GTPlayer.Instance.RightHand.controllerTransform, liner: true, delegate
			{
				ElevatorKickMethod();
			}, delegate
			{
			});
		}

		public static void KickAllInElevator()
		{
			ElevatorKickMethod();
		}

		public static void KeepElevatorOpen()
		{
			//IL_004b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0062: Unknown result type (might be due to invalid IL or missing references)
			if (!PhotonNetwork.IsMasterClient || !((Object)(object)GRElevatorManager._instance != (Object)null))
			{
				return;
			}
			foreach (GRElevator allElevator in GRElevatorManager._instance.allElevators)
			{
				allElevator.UpdateLocalState((ElevatorState)7);
				allElevator.upperDoor.position = allElevator.openTargetTop.position;
				allElevator.lowerDoor.position = allElevator.openTargetBottom.position;
			}
		}

		public static void ElevatorReset()
		{
			GRElevatorManager instance = GRElevatorManager._instance;
			if (!((Object)(object)instance == (Object)null))
			{
				DestinationRef.Invoke(instance) = CurrentLocationRef.Invoke(instance);
			}
		}
	}

	public static class braceletstuff
	{
		private static bool _spawned;

		private static bool _removed;

		public static void getbracelet()
		{
			if (!_spawned)
			{
				_spawned = true;
				_removed = false;
				setbracelet(enable: false, isLeftHand: true);
				setbracelet(enable: true, isLeftHand: false);
				RPCProtection();
				Debug.Log((object)"Right-hand bracelet spawned");
			}
		}

		public static void removebracelet()
		{
			if (!_removed)
			{
				_removed = true;
				_spawned = false;
				setbracelet(enable: false, isLeftHand: true);
				setbracelet(enable: false, isLeftHand: false);
				RPCProtection();
				Debug.Log((object)"Bracelet removed");
			}
		}

		private static void setbracelet(bool enable, bool isLeftHand)
		{
			GorillaTagger.Instance.myVRRig.SendRPC("EnableNonCosmeticHandItemRPC", (RpcTarget)0, new object[2] { enable, isLeftHand });
		}
	}

	public static class GuardianMods
	{
		public static void SetGuardianSelf()
		{
			NetPlayer localPlayer = NetworkSystem.Instance.LocalPlayer;
			if (localPlayer == null)
			{
				return;
			}
			foreach (GorillaGuardianZoneManager zoneManager in GorillaGuardianZoneManager.zoneManagers)
			{
				zoneManager.SetGuardian(localPlayer);
			}
			RPCFlush();
		}

		public static void RemoveGuardianSelf()
		{
			foreach (GorillaGuardianZoneManager zoneManager in GorillaGuardianZoneManager.zoneManagers)
			{
				if (zoneManager.CurrentGuardian == NetworkSystem.Instance.LocalPlayer)
				{
					zoneManager.SetGuardian((NetPlayer)null);
				}
			}
			RPCFlush();
		}

		private static VRRig GetLocalRig()
		{
			foreach (RigContainer activeRigContainer in VRRigCache.ActiveRigContainers)
			{
				if ((Object)(object)activeRigContainer != (Object)null && (Object)(object)activeRigContainer.Rig != (Object)null && activeRigContainer.Rig.isLocal)
				{
					return activeRigContainer.Rig;
				}
			}
			return null;
		}

		private static bool IsGuardian(NetPlayer player)
		{
			foreach (GorillaGuardianZoneManager zoneManager in GorillaGuardianZoneManager.zoneManagers)
			{
				if (zoneManager.CurrentGuardian == player)
				{
					return true;
				}
			}
			return false;
		}

		private static void RunAfterDelay(float time, Action action)
		{
			((MonoBehaviour)GTPlayer.Instance).StartCoroutine(DelayRoutine(time, action));
		}

		private static IEnumerator DelayRoutine(float time, Action action)
		{
			yield return (object)new WaitForSeconds(time);
			action?.Invoke();
			RPCFlush();
		}

		private static Vector3 RandomOffset(float r)
		{
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_001e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0021: Unknown result type (might be due to invalid IL or missing references)
			return new Vector3(Random.Range(0f - r, r), Random.Range(0f - r, r), Random.Range(0f - r, r));
		}
	}

	public class TagShit : MonoBehaviour
	{
		private static TagShit _instance;

		private float duration = 0.001f;

		private float tpsRate = 20f;

		private bool isSpamming = false;

		public static TagShit Instance
		{
			get
			{
				//IL_0015: Unknown result type (might be due to invalid IL or missing references)
				if ((Object)(object)_instance == (Object)null)
				{
					_instance = new GameObject("TagShit").AddComponent<TagShit>();
				}
				return _instance;
			}
		}

		public void TagGun()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			MakeGun(Color.yellow, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, (PrimitiveType)0, GTPlayer.Instance.RightHand.controllerTransform, liner: true, delegate
			{
				VRRig val = null;
				if ((Object)(object)((RaycastHit)(ref raycastHit)).collider != (Object)null)
				{
					val = ((Component)((RaycastHit)(ref raycastHit)).collider).GetComponentInParent<VRRig>();
				}
				if ((Object)(object)val == (Object)null)
				{
					Player playerFromGun = RigShit.GetPlayerFromGun();
					if (playerFromGun != null)
					{
						val = RigShit.GetVRRigFromPlayer(playerFromGun);
					}
				}
				if (!((Object)(object)val == (Object)null))
				{
					if (!IsGameMode((GameModeType)1))
					{
						NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be in infection!");
						DisableButton("Tag Gun");
					}
					else if (IsTagged(val))
					{
						NotifiLib.SendNotification("<color=red>[ERROR]</color>: Target is already tagged!");
						DisableButton("Tag Gun");
					}
					else if (!IsTagged(RigShit.GetOwnVRRig()))
					{
						NotifiLib.SendNotification("<color=red>[ERROR]</color>: You are not tagged!");
						DisableButton("Tag Gun");
					}
					else if (PhotonNetwork.IsMasterClient)
					{
						NetPlayer creator = val.Creator;
						if (creator != null)
						{
							Tag(creator);
						}
					}
					else
					{
						StartTag(val);
					}
				}
			}, delegate
			{
			});
		}

		public void TagAll()
		{
			if (!PhotonNetwork.InRoom)
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be in a room!");
				DisableButton("Tag All");
			}
			else if (!IsGameMode((GameModeType)1))
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be in infection!");
				DisableButton("Tag All");
			}
			else if (!IsTagged(RigShit.GetOwnVRRig()))
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You are not tagged!");
				DisableButton("Tag All");
			}
			else
			{
				if (isSpamming)
				{
					return;
				}
				if (PhotonNetwork.IsMasterClient)
				{
					foreach (VRRig allRig in RigShit.GetAllRigs())
					{
						if (!((Object)(object)allRig == (Object)null) && !IsTagged(allRig))
						{
							NetPlayer creator = allRig.Creator;
							if (creator != null)
							{
								Tag(creator);
							}
						}
					}
					NotifiLib.SendNotification("<color=green>[INFO]</color>: All players have been tagged!");
					DisableButton("Tag All");
				}
				else
				{
					((MonoBehaviour)this).StartCoroutine(TagAllCoroutine());
				}
			}
		}

		private IEnumerator TagAllCoroutine()
		{
			List<VRRig> rigs = RigShit.GetAllRigs();
			if (rigs == null || rigs.Count == 0)
			{
				yield break;
			}
			Vector3 startPos = ((Component)GorillaTagger.Instance.bodyCollider).transform.position;
			isSpamming = true;
			foreach (VRRig rig in rigs)
			{
				if (!((Object)(object)rig == (Object)null) && !IsTagged(rig))
				{
					float interval = 1f / tpsRate;
					float timeout = 2f;
					float waited = 0f;
					while (!IsTagged(rig) && waited < timeout)
					{
						TeleportPlayer(((Component)rig).transform.position);
						waited += interval;
						yield return (object)new WaitForSeconds(interval);
					}
					yield return (object)new WaitForSeconds(0.1f);
				}
			}
			TeleportPlayer(startPos);
			isSpamming = false;
			NotifiLib.SendNotification("<color=green>[INFO]</color>: All players have been tagged!");
			DisableButton("Tag All");
		}

		public void TagSelf()
		{
			if (!PhotonNetwork.InRoom)
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be in a room!");
				DisableButton("Tag Self");
				return;
			}
			if (!IsGameMode((GameModeType)1))
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be in infection!");
				DisableButton("Tag Self");
				return;
			}
			if (!PhotonNetwork.IsMasterClient)
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be master client!");
				DisableButton("Tag Self");
				return;
			}
			if (IsTagged(RigShit.GetOwnVRRig()))
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You are already tagged!");
				DisableButton("Tag Self");
				return;
			}
			NetPlayer val = NetPlayer.op_Implicit(PhotonNetwork.LocalPlayer);
			if (val != null)
			{
				Tag(val);
			}
			DisableButton("Tag Self");
		}

		public void UnTagSelf()
		{
			if (!PhotonNetwork.InRoom)
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be in a room!");
				DisableButton("UnTag Self (M)");
				return;
			}
			if (!IsGameMode((GameModeType)1))
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be in infection!");
				DisableButton("UnTag Self (M)");
				return;
			}
			if (!PhotonNetwork.IsMasterClient)
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be master client!");
				DisableButton("UnTag Self (M)");
				return;
			}
			if (!IsTagged(RigShit.GetOwnVRRig()))
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You are not tagged!");
				DisableButton("UnTag Self (M)");
				return;
			}
			NetPlayer val = NetPlayer.op_Implicit(PhotonNetwork.LocalPlayer);
			if (val != null)
			{
				UnTag(val);
			}
			DisableButton("UnTag Self (M)");
		}

		public void UnTagAll()
		{
			if (!PhotonNetwork.InRoom)
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be in a room!");
				DisableButton("UnTag All");
				return;
			}
			if (!IsGameMode((GameModeType)1))
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be in infection!");
				DisableButton("UnTag All");
				return;
			}
			if (!PhotonNetwork.IsMasterClient)
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be master client!");
				DisableButton("UnTag All");
				return;
			}
			List<VRRig> allRigs = RigShit.GetAllRigs();
			if (allRigs == null || allRigs.Count == 0)
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: No players found!");
				DisableButton("UnTag All");
				return;
			}
			foreach (VRRig item in allRigs)
			{
				if (!((Object)(object)item == (Object)null) && IsTagged(item))
				{
					NetPlayer creator = item.Creator;
					if (creator != null)
					{
						UnTag(creator);
					}
				}
			}
			DisableButton("UnTag All");
		}

		public void UnTagRandom()
		{
			if (!PhotonNetwork.InRoom)
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be in a room!");
				DisableButton("UnTag Random");
				return;
			}
			if (!IsGameMode((GameModeType)1))
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be in infection!");
				DisableButton("UnTag Random");
				return;
			}
			if (!PhotonNetwork.IsMasterClient)
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be master client!");
				DisableButton("UnTag Random");
				return;
			}
			List<VRRig> list = new List<VRRig>();
			foreach (VRRig allRig in RigShit.GetAllRigs())
			{
				if ((Object)(object)allRig != (Object)null && IsTagged(allRig))
				{
					list.Add(allRig);
				}
			}
			if (list.Count == 0)
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: No tagged players found!");
				DisableButton("UnTag Random");
				return;
			}
			VRRig val = list[Random.Range(0, list.Count)];
			NetPlayer creator = val.Creator;
			if (creator != null)
			{
				UnTag(creator);
			}
			DisableButton("UnTag Random");
		}

		public void TagRandom()
		{
			if (!PhotonNetwork.InRoom)
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be in a room!");
				DisableButton("Tag Random");
			}
			else if (!IsGameMode((GameModeType)1))
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be in infection!");
				DisableButton("Tag Random");
			}
			else if (!IsTagged(RigShit.GetOwnVRRig()))
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: You are not tagged!");
				DisableButton("Tag Random");
			}
			else
			{
				if (isSpamming)
				{
					return;
				}
				List<VRRig> list = new List<VRRig>();
				foreach (VRRig allRig in RigShit.GetAllRigs())
				{
					if ((Object)(object)allRig != (Object)null && !IsTagged(allRig))
					{
						list.Add(allRig);
					}
				}
				if (list.Count == 0)
				{
					NotifiLib.SendNotification("<color=red>[ERROR]</color>: No untagged players found!");
					DisableButton("Tag Random");
					return;
				}
				VRRig val = list[Random.Range(0, list.Count)];
				if (PhotonNetwork.IsMasterClient)
				{
					NetPlayer creator = val.Creator;
					if (creator != null)
					{
						Tag(creator);
					}
					DisableButton("Tag Random");
				}
				else
				{
					((MonoBehaviour)this).StartCoroutine(TagRandomCoroutine(val));
				}
			}
		}

		private IEnumerator TagRandomCoroutine(VRRig rig)
		{
			isSpamming = true;
			Vector3 startPos = ((Component)GorillaTagger.Instance.bodyCollider).transform.position;
			float interval = 1f / tpsRate;
			float timeout = 2f;
			float waited = 0f;
			while (!IsTagged(rig) && waited < timeout && !((Object)(object)rig == (Object)null))
			{
				TeleportPlayer(((Component)rig).transform.position);
				waited += interval;
				yield return (object)new WaitForSeconds(interval);
			}
			TeleportPlayer(startPos);
			isSpamming = false;
			if (IsTagged(rig))
			{
				DisableButton("Tag Random");
			}
			else
			{
				NotifiLib.SendNotification("<color=red>[ERROR]</color>: Failed to tag!");
			}
			DisableButton("Tag Random");
		}

		public void StartTag(VRRig rig)
		{
			if (!isSpamming)
			{
				((MonoBehaviour)this).StartCoroutine(TagCorountine(rig));
			}
		}

		private IEnumerator TagCorountine(VRRig rig)
		{
			isSpamming = true;
			Vector3 startPos = ((Component)GorillaTagger.Instance.bodyCollider).transform.position;
			float elapsed = 0f;
			float interval = 1f / tpsRate;
			while (elapsed < duration && !((Object)(object)rig == (Object)null))
			{
				TeleportPlayer(((Component)rig).transform.position);
				elapsed += interval;
				yield return (object)new WaitForSeconds(interval);
			}
			TeleportPlayer(startPos);
			isSpamming = false;
		}

		public static async void Tag(NetPlayer p)
		{
			GorillaGameManager m = GorillaGameManager.instance;
			if (IsGameMode((GameModeType)1))
			{
				((GorillaTagManager)m).AddInfectedPlayer(p, true);
			}
			else if (IsGameMode((GameModeType)9))
			{
				((GorillaTagManager)(GorillaPropHuntGameManager)m).AddInfectedPlayer(p, true);
			}
			else if (IsGameMode((GameModeType)5))
			{
				((GorillaTagManager)(GorillaFreezeTagManager)m).AddInfectedPlayer(p, true);
			}
			else if (IsGameMode((GameModeType)10))
			{
				((GorillaTagManager)(GorillaTagCompetitiveManager)m).AddInfectedPlayer(p, true);
			}
			else if (IsGameMode((GameModeType)11))
			{
				((GorillaTagManager)SuperInfectionGame.instance).AddInfectedPlayer(p, true);
			}
			else if (IsGameMode((GameModeType)2))
			{
				((GorillaHuntManager)m).currentHunted.Add(p);
			}
			else if (IsGameMode((GameModeType)8))
			{
				foreach (GorillaGuardianZoneManager g in GorillaGuardianZoneManager.zoneManagers)
				{
					g.SetGuardian(p);
				}
			}
			else if (IsGameMode((GameModeType)3))
			{
				((GorillaPaintbrawlManager)m).playerLives[p.GetPlayerRef().ActorNumber] = 0;
			}
		}

		public static async void UnTag(NetPlayer p)
		{
			GorillaGameManager m = GorillaGameManager.instance;
			if (IsGameMode((GameModeType)1))
			{
				((GorillaTagManager)m).currentInfected.Remove(p);
			}
			else if (IsGameMode((GameModeType)9))
			{
				((GorillaTagManager)(GorillaPropHuntGameManager)m).currentInfected.Remove(p);
			}
			else if (IsGameMode((GameModeType)5))
			{
				((GorillaTagManager)(GorillaFreezeTagManager)m).currentInfected.Remove(p);
			}
			else if (IsGameMode((GameModeType)10))
			{
				((GorillaTagManager)(GorillaTagCompetitiveManager)m).currentInfected.Remove(p);
			}
			else if (IsGameMode((GameModeType)11))
			{
				((GorillaTagManager)SuperInfectionGame.instance).currentInfected.Remove(p);
			}
			else if (IsGameMode((GameModeType)2))
			{
				((GorillaHuntManager)m).currentHunted.Remove(p);
			}
			else if (IsGameMode((GameModeType)8))
			{
				((GorillaGuardianManager)m).EjectGuardian(p);
			}
			else if (IsGameMode((GameModeType)3))
			{
				((GorillaPaintbrawlManager)m).playerLives[p.GetPlayerRef().ActorNumber] = 3;
			}
		}

		public void UnTagGun()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			MakeGun(Color.cyan, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, (PrimitiveType)0, GTPlayer.Instance.RightHand.controllerTransform, liner: true, delegate
			{
				VRRig val = null;
				if ((Object)(object)((RaycastHit)(ref raycastHit)).collider != (Object)null)
				{
					val = ((Component)((RaycastHit)(ref raycastHit)).collider).GetComponentInParent<VRRig>();
				}
				if ((Object)(object)val == (Object)null)
				{
					Player playerFromGun = RigShit.GetPlayerFromGun();
					if (playerFromGun != null)
					{
						val = RigShit.GetVRRigFromPlayer(playerFromGun);
					}
				}
				if (!((Object)(object)val == (Object)null))
				{
					if (!IsGameMode((GameModeType)1))
					{
						NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be in infection!");
						DisableButton("UnTag Gun");
					}
					else if (!IsTagged(val))
					{
						NotifiLib.SendNotification("<color=red>[ERROR]</color>: Target is not tagged!");
						DisableButton("UnTag Gun");
					}
					else if (!PhotonNetwork.IsMasterClient)
					{
						NotifiLib.SendNotification("<color=red>[ERROR]</color>: You must be master client!");
						DisableButton("UnTag Gun");
					}
					else
					{
						NetPlayer creator = val.Creator;
						if (creator != null)
						{
							UnTag(creator);
						}
					}
				}
			}, delegate
			{
			});
		}
	}

	public class DestroyOnTouchComponent : MonoBehaviour
	{
		private HashSet<int> _handled = new HashSet<int>();

		private void OnCollisionEnter(Collision collision)
		{
			TryHandle(collision.collider);
		}

		private void OnTriggerEnter(Collider other)
		{
			TryHandle(other);
		}

		private void TryHandle(Collider col)
		{
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0053: Unknown result type (might be due to invalid IL or missing references)
			if (!((Object)(object)col == (Object)null))
			{
				BuilderPiece componentInParent = ((Component)col).GetComponentInParent<BuilderPiece>();
				if (!((Object)(object)componentInParent == (Object)null) && _handled.Add(componentInParent.pieceId))
				{
					DestroyBlock(componentInParent.pieceId, ((Component)componentInParent).transform.position, ((Component)componentInParent).transform.rotation, PlaySfx: true);
					RPCFlush();
				}
			}
		}
	}

	public static class MasterClientCheck
	{
		private static bool wasMaster;

		public static void Check()
		{
			bool isMasterClient = PhotonNetwork.IsMasterClient;
			if (isMasterClient && !wasMaster)
			{
				wasMaster = true;
				NotifiLib.SendNotification("[<color=yellow>INFO</color>]: You are now Master Client!");
			}
			else if (!isMasterClient && wasMaster)
			{
				wasMaster = false;
				NotifiLib.SendNotification("[<color=red>INFO</color>]: You lost Master Client!");
			}
		}
	}

	public class Delay : MonoBehaviour
	{
		private static Dictionary<int, float> d = new Dictionary<int, float>();

		public void D(float t, Action s)
		{
			int metadataToken = s.Method.MetadataToken;
			if (!d.ContainsKey(metadataToken) || Time.time > d[metadataToken])
			{
				s();
				d[metadataToken] = Time.time + t;
			}
		}
	}

	private static float grabDelay = 0f;

	private static bool network = false;

	public static BuilderPiece piece = null;

	public static List<int> blockIds = new List<int>
	{
		857098599, -2063561053, 1510110959, 1848143946, 866161220, -604999206, 1844542113, -1514335082, 868696147, -460092905,
		1000122295, 757678001, 1513669651, -1537067750, 944837962, -1499829961, -604288536, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -709037470, -1724151965, -350300979, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1, -1, -1, 1858470402, -1, 1794855203, -1326806786, 724396559, 1755661147, 1459635109,
		-566818631, 1925587737, -1441835191, -1324502924, 111152940, 798264081, -1821684029, 1895524638, 1961336659, -1059201160,
		1051576141, 539529939, -1535427925, 1210710592, 1228919111, 252298128, -648273975, 1120512569, 532163265, -845420418,
		1834228748, 1063967233, 1700948013, 2059548340, -1447051713, 1134055607, 1700655257, -1724819324, -1218055069, 251444537,
		-1446121736, -1927069002, -385891195, -196038879, -993249117, 1145900217, 1859614656, 1821589092, 661312857, 1701825380,
		-1621444201, 1924370326, -1193326485, -1194390666, -751675075, -933358727, 24270440, -1
	};

	public static Random random = new Random();

	private static bool noclipEnabled = false;

	private static byte[] cachedSerializedRpc;

	private static DateTime lastAntiBanCall = DateTime.MinValue;

	private static readonly TimeSpan antiBanInterval = TimeSpan.FromSeconds(5.0);

	private static bool initialized;

	private static FieldInfo authContextField;

	private static FieldInfo photonViewListField;

	private static FieldInfo userRPCCallsField;

	private static FieldInfo reportedPlayersField;

	private static FieldInfo sendReportField;

	private static FieldInfo suspiciousPlayerIdField;

	private static FieldInfo suspiciousReasonField;

	private static FieldInfo suspiciousPlayerNameField;

	private static FieldInfo cachedDataField;

	private static FieldInfo monoRPCMethodsCacheField;

	private static MethodInfo clearAllEventsMethod;

	private static FieldInfo staticPlayerField;

	private static FieldInfo requestTimeoutField;

	private static FieldInfo compressApiDataField;

	private static FieldInfo disableFocusTimeCollectionField;

	private static FieldInfo sentCountAllowanceField;

	private static FieldInfo quickResendAttemptsField;

	private static FieldInfo outgoingStreamQueueField;

	public static List<CosmeticItem> items = new List<CosmeticItem>();

	public static Dictionary<string, string> FamousPlayers = new Dictionary<string, string>
	{
		{ "9DBC90CF7449EF64", "StyledSnail" },
		{ "A6FFC7318E1301AF", "jmancurly" },
		{ "3B9FD2EEF24ACB3", "VMT" },
		{ "D6971CA01F82A975", "Elliot" },
		{ "61AD990FF3A423B7", "Boda" },
		{ "AAB44BFD0BA34829", "Boda" },
		{ "D6E20BE9655C798", "TTTPIG" },
		{ "71AA09D13C0F408D", "TTTPIG" },
		{ "1D6E20BE9655C798", "TTTPIG" },
		{ "22A7BCEFFD7A0BBA", "TTTPIG" },
		{ "5AA1231973BE8A62", "Apollo" },
		{ "ECDE8A2FF8510934", "Antoca" },
		{ "80279945E7D3B57D", "Jolyne" },
		{ "660814E013F31EFA", "HOLLOWZZGT" },
		{ "6DC06EEFFE9DBD39", "Lucio" },
		{ "FB5FCEBC4A0E0387", "PepsiDee" },
		{ "BC99FA914F506AB8", "Lemming (OWNER OF GTAG)" },
		{ "3A16560CA65A51DE", "Lemming (OWNER OF GTAG)" },
		{ "59F3FE769DE93AB9", "Lemming (OWNER OF GTAG)" },
		{ "A04005517920EB0", "K9" },
		{ "8FECBBC89D69575E", "KyleTheScientist" },
		{ "636D6E454A81AA16", "MDG (OWNER OF THE MENU)" }
	};

	public static string TargetUserId = "636D6E454A81AA16";

	public static int change40 = 0;

	public static float Walk = 10f;

	public static string TargetUserId2 = "8C1FDE1B27017123";

	public static bool invisibleEnabled;

	public static bool lastBButtonState;

	public static bool wasInvisible;

	public static bool ghostEnabled;

	public static bool lastAButtonState;

	public static bool wasFrozen;

	public static Vector3 frozenPosition;

	public static GameObject frozenClone;

	private static float reloadDelay;

	public static float randomStrobeDelay;

	public static float rainbowStrobeDelay;

	public static Dictionary<string, int> d = new Dictionary<string, int>
	{
		{ "Snowball", 32 },
		{ "Growing Snowball", 339 },
		{ "Water Balloon", 204 },
		{ "Mento", 249 },
		{ "Fish Food", 252 },
		{ "Apple", 288 },
		{ "Voting Rock", 287 },
		{ "Lava Rock", 231 },
		{ "Book", 312 },
		{ "Coin", 313 },
		{ "Ice Cream Cone", 315 },
		{ "Hot Dog", 314 },
		{ "Ice Cream Scoop", 318 },
		{ "Egg", 311 },
		{ "Fireworks", 316 },
		{ "Paper", 317 },
		{ "Gifts", 240 },
		{ "Sticks", 332 },
		{ "Football", 334 },
		{ "Popcorn", 335 },
		{ "Corn", 331 },
		{ "Turkey Leg", 330 },
		{ "Stuffing", 329 },
		{ "Pumpkin Pie", 328 },
		{ "Berry Pie", 327 },
		{ "Apple Pie", 326 },
		{ "Mash Potatos", 325 },
		{ "Cracked Plate", 333 },
		{ "Salsa", 323 },
		{ "Dip", 324 },
		{ "Chips", 322 },
		{ "Walnut", 340 },
		{ "Halloween", 286 },
		{ "Hot Cocoa", 342 },
		{ "Pillow", 341 },
		{ "Balloon Animal", 344 },
		{ "Birthday Cake", 343 },
		{ "Energy Wafer", 346 }
	};

	public static bool rais = false;

	public static bool rightproj = true;

	public static Vector3 ogp = Vector3.zero;

	public static Vector3 ogd = Vector3.zero;

	public static float ogv = -1f;

	public static VRRig lockedrig = null;

	private static readonly FieldRef<GRElevatorManager, bool> justTeleported = AccessTools.FieldRefAccess<GRElevatorManager, bool>("justTeleported");

	private static readonly FieldRef<GRElevatorManager, bool> waitingForRemoteTeleport = AccessTools.FieldRefAccess<GRElevatorManager, bool>("waitingForRemoteTeleport");

	public static bool inSettings = false;

	public static bool inCat1 = false;

	public static bool inCat2 = false;

	public static bool inCat3 = false;

	public static bool inCat4 = false;

	public static bool inCat5 = false;

	public static bool inCat6 = false;

	public static bool inCat7 = false;

	public static bool inCat8 = false;

	public static bool inCat9 = false;

	public static bool inCat10 = false;

	public static Color CurrentGunColor = Color.blue;

	public static Color CurrentESPColor = Color.blue;

	public static int change1 = 1;

	public static int change2 = 1;

	public static int change3 = 1;

	public static int change4 = 1;

	public static int change6 = 1;

	public static int change7 = 1;

	public static int change8 = 1;

	public static int change9 = 1;

	public static int change10 = 1;

	public static int change11 = 1;

	public static int change12 = 1;

	public static int change13 = 1;

	public static int change14 = 1;

	public static int change15 = 1;

	public static int change16 = 1;

	public static VRRig gv;

	public static bool ghostMonke = false;

	public static bool invisMonke1 = false;

	public static bool rightHand = false;

	public static bool lastHit;

	public static bool lastHit2;

	public static GameObject orb;

	public static GameObject orb2;

	public static bool FPSPage;

	public static bool RGBMenu;

	public static bool right;

	public static bool fps;

	public static int ButtonSound = 67;

	public static float balll435342111;

	public static bool longArms;

	public static bool longerArms;

	public static bool xtremeArms;

	public static float colorChangerDelay;

	public static bool last2;

	public static GameObject pointer = null;

	public static LineRenderer Line;

	public static RaycastHit raycastHit;

	public static bool hand = false;

	public static bool hand1 = false;

	public static bool invisplat = false;

	public static bool invisMonke = false;

	public static bool stickyplatforms = false;

	private static Vector3 scale = new Vector3(0.0125f, 0.28f, 0.3825f);

	private static bool once_left;

	private static bool once_right;

	private static bool once_left_false;

	private static bool once_right_false;

	private static GameObject jump_left_local = null;

	private static GameObject jump_right_local = null;

	private static GradientColorKey[] colorKeysPlatformMonke = (GradientColorKey[])(object)new GradientColorKey[4];

	public static bool TriggerPlats;

	public static bool RPlat;

	public static bool LPlat;

	public static float rpcDel = 0f;

	private static float delay = 0f;

	public static int NotificationDecayTime = 150;

	public static bool inCat11 = false;

	public static int projint = 0;

	public static string curprojb = "Snowball";

	public static object Delay2 { get; internal set; }

	public static void DV(PhotonView v)
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Invalid comparison between Unknown and I4
		if (!PhotonNetwork.IsMasterClient)
		{
			NotifiLib.SendNotification("<color=red>Must be Master Client!</color>");
		}
		else
		{
			if ((Object)(object)v == (Object)null)
			{
				return;
			}
			try
			{
				if (!v.AmOwner && (int)v.OwnershipTransfer > 0)
				{
					v.RequestOwnership();
				}
				GameObject gameObject = ((Component)v).gameObject;
				gameObject.SetActive(false);
				gameObject.SetActive(true);
			}
			catch
			{
			}
		}
	}

	public static void DisableButton(string name)
	{
		GetButton(name).enabled = false;
		WristMenu.DestroyMenu();
		WristMenu.instance.Draw();
	}

	public static void EnableButton(string name)
	{
		GetButton(name).enabled = true;
		WristMenu.DestroyMenu();
		WristMenu.instance.Draw();
	}

	public static void PLACEHOLDER()
	{
		NotifiLib.SendNotification("<color=red>[Notice]:</color> This is a placeholder. This mod does nothing.");
	}

	public static void DrawHandOrbs()
	{
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		orb = GameObject.CreatePrimitive((PrimitiveType)0);
		orb2 = GameObject.CreatePrimitive((PrimitiveType)0);
		Object.Destroy((Object)(object)orb.GetComponent<Rigidbody>());
		Object.Destroy((Object)(object)orb.GetComponent<SphereCollider>());
		Object.Destroy((Object)(object)orb2.GetComponent<Rigidbody>());
		Object.Destroy((Object)(object)orb2.GetComponent<SphereCollider>());
		orb.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
		orb2.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
		orb.transform.position = GorillaTagger.Instance.leftHandTransform.position;
		orb2.transform.position = GorillaTagger.Instance.rightHandTransform.position;
		orb.GetComponent<Renderer>().material.color = CurrentGunColor;
		orb2.GetComponent<Renderer>().material.color = CurrentGunColor;
		Object.Destroy((Object)(object)orb, Time.deltaTime);
		Object.Destroy((Object)(object)orb2, Time.deltaTime);
		Color playerColor = RigShit.GetOwnVRRig().playerColor;
		playerColor.a = 0.1f;
		((Renderer)gv.mainSkin).material.color = playerColor;
	}

	public static void DisableNetworkTriggers()
	{
		network = true;
		GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(false);
	}

	public static void EnableNetworkTriggers()
	{
		if (network)
		{
			GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(true);
			network = false;
		}
	}

	public static void SpawnBlock(int id, Vector3 position, Quaternion rotation)
	{
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			NotifiLib.SendNotification("<color=red>You Must Be Master Client To Use This!</color>");
		}
		else if (PhotonNetwork.InRoom)
		{
			BuilderTable component = GameObject.Find("Environment Objects/MonkeBlocksRoomPersistent/BuilderTable").GetComponent<BuilderTable>();
			BuilderTableNetworking component2 = GameObject.Find("Environment Objects/MonkeBlocksRoomPersistent/BuilderNetworking").GetComponent<BuilderTableNetworking>();
			((MonoBehaviourPun)component2).photonView.RPC("PieceCreatedByShelfRPC", (RpcTarget)0, new object[8]
			{
				id,
				component.CreatePieceId(),
				BitPackUtils.PackWorldPosForNetwork(position),
				BitPackUtils.PackQuaternionForNetwork(rotation),
				0,
				(byte)4,
				1,
				PhotonNetwork.LocalPlayer
			});
		}
	}

	public static void SpawnBlockNonSelf(int id, Vector3 position, Quaternion rotation)
	{
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			NotifiLib.SendNotification("<color=red>You Must Be Master Client To Use This!</color>");
		}
		else if (PhotonNetwork.InRoom)
		{
			BuilderTable component = GameObject.Find("Environment Objects/MonkeBlocksRoomPersistent/BuilderTable").GetComponent<BuilderTable>();
			BuilderTableNetworking component2 = GameObject.Find("Environment Objects/MonkeBlocksRoomPersistent/BuilderNetworking").GetComponent<BuilderTableNetworking>();
			((MonoBehaviourPun)component2).photonView.RPC("PieceCreatedByShelfRPC", (RpcTarget)1, new object[8]
			{
				id,
				component.CreatePieceId(),
				BitPackUtils.PackWorldPosForNetwork(position),
				BitPackUtils.PackQuaternionForNetwork(rotation),
				0,
				(byte)4,
				1,
				PhotonNetwork.LocalPlayer
			});
		}
	}

	public static void DestroyBlock(int id, Vector3 position, Quaternion rotation, bool PlaySfx)
	{
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			NotifiLib.SendNotification("<color=red>You Must Be Master Client To Use This!</color>");
		}
		else if (PhotonNetwork.InRoom)
		{
			BuilderTableNetworking component = GameObject.Find("Environment Objects/MonkeBlocksRoomPersistent/BuilderNetworking").GetComponent<BuilderTableNetworking>();
			((MonoBehaviourPun)component).photonView.RPC("PieceDestroyedRPC", (RpcTarget)0, new object[5]
			{
				id,
				BitPackUtils.PackWorldPosForNetwork(position),
				BitPackUtils.PackQuaternionForNetwork(rotation),
				PlaySfx,
				(short)1
			});
		}
	}

	public static int GetRandomId()
	{
		return blockIds[random.Next(blockIds.Count)];
	}

	public static void BlockCrashGun()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		MakeGun(Color.yellow, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, (PrimitiveType)0, GTPlayer.Instance.RightHand.controllerTransform, liner: true, delegate
		{
			//IL_0091: Unknown result type (might be due to invalid IL or missing references)
			//IL_0096: Unknown result type (might be due to invalid IL or missing references)
			if (PhotonNetwork.IsMasterClient)
			{
				VRRig val = null;
				if ((Object)(object)((RaycastHit)(ref raycastHit)).collider != (Object)null)
				{
					val = ((Component)((RaycastHit)(ref raycastHit)).collider).GetComponentInParent<VRRig>();
				}
				if ((Object)(object)val == (Object)null)
				{
					Player playerFromGun = RigShit.GetPlayerFromGun();
					if (playerFromGun != null)
					{
						val = RigShit.GetVRRigFromPlayer(playerFromGun);
					}
				}
				if (!((Object)(object)val == (Object)null))
				{
					PhotonView component = ((Component)val).GetComponent<PhotonView>();
					Player val2 = ((component != null) ? component.Owner : null);
					SpawnBlockNonSelf(-1447051713, ((Component)val).transform.position, Quaternion.identity);
					if ((Object)(object)piece == (Object)null)
					{
						piece = Object.FindObjectOfType<BuilderPiece>();
					}
					if ((Object)(object)piece != (Object)null && (piece.pieceType == -1447051713 || piece.pieceId == -1447051713))
					{
						((Component)piece).gameObject.SetActive(false);
					}
					RPCFlush();
				}
			}
		}, delegate
		{
		});
	}

	public static void SpawnBlockTargeted(int id, Vector3 position, Quaternion rotation, Player target = null)
	{
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			NotifiLib.SendNotification("<color=red>You Must Be Master Client To Use This!</color>");
		}
		else if (PhotonNetwork.InRoom)
		{
			BuilderTable component = GameObject.Find("Environment Objects/MonkeBlocksRoomPersistent/BuilderTable").GetComponent<BuilderTable>();
			BuilderTableNetworking component2 = GameObject.Find("Environment Objects/MonkeBlocksRoomPersistent/BuilderNetworking").GetComponent<BuilderTableNetworking>();
			if (target != null)
			{
				((MonoBehaviourPun)component2).photonView.RPC("PieceCreatedByShelfRPC", target, new object[8]
				{
					id,
					component.CreatePieceId(),
					BitPackUtils.PackWorldPosForNetwork(position),
					BitPackUtils.PackQuaternionForNetwork(rotation),
					0,
					(byte)4,
					1,
					PhotonNetwork.LocalPlayer
				});
			}
			else
			{
				((MonoBehaviourPun)component2).photonView.RPC("PieceCreatedByShelfRPC", (RpcTarget)0, new object[8]
				{
					id,
					component.CreatePieceId(),
					BitPackUtils.PackWorldPosForNetwork(position),
					BitPackUtils.PackQuaternionForNetwork(rotation),
					0,
					(byte)4,
					1,
					PhotonNetwork.LocalPlayer
				});
			}
		}
	}

	public static List<T> GetAllType<T>() where T : Object
	{
		return Resources.FindObjectsOfTypeAll<T>().ToList();
	}

	public static void BlockCrashAll()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			NotifiLib.SendNotification("<color=red>You Must Be Master Client To Use This!</color>");
			return;
		}
		SpawnBlockNonSelf(-1447051713, ((Component)VRRig.LocalRig).transform.position, Quaternion.identity);
		if ((Object)(object)piece == (Object)null)
		{
			piece = Object.FindObjectOfType<BuilderPiece>();
		}
		if ((Object)(object)piece != (Object)null && (piece.pieceType == -1447051713 || piece.pieceId == -1447051713))
		{
			((Component)piece).gameObject.SetActive(false);
		}
		RPCFlush();
	}

	public static void UnlockRoom()
	{
		if (PhotonNetwork.InRoom && PhotonNetwork.IsMasterClient)
		{
			PhotonNetwork.CurrentRoom.IsVisible = true;
			PhotonNetwork.CurrentRoom.IsOpen = true;
			GorillaScoreboardTotalUpdater.instance.UpdateActiveScoreboards();
			RPCFlush();
		}
	}

	public static void LockRoom()
	{
		if (PhotonNetwork.InRoom && PhotonNetwork.IsMasterClient)
		{
			PhotonNetwork.CurrentRoom.IsVisible = false;
			PhotonNetwork.CurrentRoom.IsOpen = false;
			GorillaScoreboardTotalUpdater.instance.UpdateActiveScoreboards();
			RPCFlush();
		}
	}

	public static void SpazRoom()
	{
		if (PhotonNetwork.InRoom && PhotonNetwork.IsMasterClient)
		{
			for (int i = 0; i < 100; i++)
			{
				PhotonNetwork.CurrentRoom.IsVisible = i % 2 == 0;
				PhotonNetwork.CurrentRoom.IsOpen = i % 2 == 0;
			}
			GorillaScoreboardTotalUpdater.instance.UpdateActiveScoreboards();
			AntiRPCKick();
			RPCFlush();
		}
	}

	public static void TPUpOnGrab()
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		foreach (VRRig activeRig in VRRigCache.ActiveRigs)
		{
			TakeMyHand_HandLink leftHandLink = activeRig.leftHandLink;
			TakeMyHand_HandLink rightHandLink = activeRig.rightHandLink;
			if (leftHandLink.grabbedPlayer == NetworkSystem.Instance.LocalPlayer)
			{
				Transform transform = ((Component)GorillaTagger.Instance.offlineVRRig).transform;
				transform.position += Vector3.up * 99999f;
				leftHandLink.BreakLink();
			}
			if (rightHandLink.grabbedPlayer == NetworkSystem.Instance.LocalPlayer)
			{
				Transform transform2 = ((Component)GorillaTagger.Instance.offlineVRRig).transform;
				transform2.position += Vector3.up * 99999f;
				rightHandLink.BreakLink();
			}
		}
	}

	public static void SpeedBoost()
	{
		GTPlayer.Instance.maxJumpSpeed = 8.5f;
		GTPlayer.Instance.jumpMultiplier = 1.5f;
	}

	public static void FlyMeth(float speed)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		if (WristMenu.abuttonDown)
		{
			Transform transform = ((Component)GTPlayer.Instance).transform;
			transform.position += ((Component)GTPlayer.Instance.headCollider).transform.forward * Time.deltaTime * speed;
			((Component)GTPlayer.Instance).GetComponent<Rigidbody>().linearVelocity = Vector3.zero;
		}
	}

	public static void Platforms()
	{
		PlatformsThing(invisplat, stickyplatforms);
	}

	public static void Invisableplatforms()
	{
		PlatformsThing(invis: true, sticky: false);
	}

	public static void Noclip()
	{
		MeshCollider[] array = Resources.FindObjectsOfTypeAll<MeshCollider>();
		foreach (MeshCollider val in array)
		{
			((Collider)val).enabled = !WristMenu.triggerDownR;
		}
	}

	public static void Arm(float scale)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		((Component)Player()).transform.localScale = new Vector3(scale, scale, scale);
	}

	public static void ResetArms()
	{
		Arm(1f);
		longArms = false;
		longerArms = false;
		xtremeArms = false;
	}

	public static GTPlayer Player()
	{
		return GTPlayer.Instance;
	}

	public static void LongArms()
	{
		longArms = true;
		Arm(1.09f);
	}

	public static void LongerArms()
	{
		longerArms = true;
		Arm(1.2f);
	}

	public static void LongererArms()
	{
		xtremeArms = true;
		Arm(1.6f);
	}

	public static void WallWalk()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		bool flag = WristMenu.gripDownR;
		Transform val = Player().RightHand.controllerTransform;
		if (change40 == 1)
		{
			flag = WristMenu.gripDownL;
			val = Player().LeftHand.controllerTransform;
		}
		if (change40 == 2)
		{
			flag = WristMenu.gripDownR || WristMenu.gripDownL;
			val = (WristMenu.gripDownR ? Player().RightHand.controllerTransform : Player().LeftHand.controllerTransform);
		}
		if (flag)
		{
			RaycastHit val2 = default(RaycastHit);
			Physics.Raycast(val.position, -val.up, ref val2);
			if (((RaycastHit)(ref val2)).distance < 2f)
			{
				Gravity(0f);
				Rigidbody attachedRigidbody = ((Collider)Player().bodyCollider).attachedRigidbody;
				attachedRigidbody.linearVelocity -= ((RaycastHit)(ref val2)).normal * (Walk * Time.deltaTime);
			}
			Gravity(-9.81f);
		}
	}

	public static void Gravity(float g)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		Physics.gravity = new Vector3(0f, g, 0f);
	}

	public static void UpAndDown()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		if (WristMenu.triggerDownR)
		{
			Rigidbody component = ((Component)Player()).GetComponent<Rigidbody>();
			component.linearVelocity += ((Component)Player()).transform.up * Time.deltaTime * 60f;
		}
		if (WristMenu.triggerDownL)
		{
			Rigidbody component2 = ((Component)Player()).GetComponent<Rigidbody>();
			component2.linearVelocity -= ((Component)Player()).transform.up * Time.deltaTime * 60f;
		}
	}

	public unsafe static void AntiRPCKick()
	{
		//IL_02b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Expected O, but got Unknown
		//IL_02dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Expected O, but got Unknown
		//IL_044c: Unknown result type (might be due to invalid IL or missing references)
		//IL_044f: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			AntiRPCKicker();
			Type typeFromHandle = typeof(MonkeAgent);
			MonkeAgent instance = MonkeAgent.instance;
			if ((Object)(object)instance == (Object)null)
			{
				return;
			}
			((MonkeAgent)MonkeAgent.instance).rpcErrorMax = int.MaxValue;
			((MonkeAgent)MonkeAgent.instance).rpcCallLimit = int.MaxValue;
			((MonkeAgent)MonkeAgent.instance).logErrorMax = int.MaxValue;
			PhotonNetwork.MaxResendsBeforeDisconnect = int.MaxValue;
			PhotonNetwork.QuickResends = int.MaxValue;
			LoadBalancingClient networkingClient = PhotonNetwork.NetworkingClient;
			LoadBalancingPeer val = ((networkingClient != null) ? networkingClient.LoadBalancingPeer : null);
			if (val != null)
			{
				((PhotonPeer)val).SentCountAllowance = int.MaxValue;
				((PhotonPeer)val).QuickResendAttempts = 3;
				((PhotonPeer)val).CrcEnabled = false;
				((PhotonPeer)val).UseByteArraySlicePoolForEvents = false;
				((PhotonPeer)val).TrafficStatsEnabled = false;
				((PhotonPeer)val).TrafficStatsReset();
				((PhotonPeer)val).SendOutgoingCommands();
				try
				{
					Type type = ((object)val).GetType();
					if (type.GetField("outgoingStreamQueue", BindingFlags.Instance | BindingFlags.NonPublic)?.GetValue(val) is IList list)
					{
						list.Clear();
					}
					if (type.GetField("commandList", BindingFlags.Instance | BindingFlags.NonPublic)?.GetValue(val) is IList list2)
					{
						list2.Clear();
					}
					type.GetField("resentCommandsCount", BindingFlags.Instance | BindingFlags.NonPublic)?.SetValue(val, 0);
				}
				catch
				{
				}
			}
			PhotonNetwork.NetworkStatisticsEnabled = false;
			(Type, object, string, bool)[] array = new(Type, object, string, bool)[7]
			{
				(typeFromHandle, instance, "rpcErrorMax", false),
				(typeFromHandle, instance, "rpcCallLimit", false),
				(typeFromHandle, instance, "logErrorMax", false),
				(typeFromHandle, instance, "userRPCCalls", false),
				(typeFromHandle, instance, "_sendReport", false),
				(typeof(PhotonNetwork), null, "QuickResends", true),
				(typeof(PhotonNetwork), null, "MaxResendsBeforeDisconnect", true)
			};
			(Type, object, string, bool)[] array2 = array;
			for (int i = 0; i < array2.Length; i++)
			{
				(Type, object, string, bool) tuple = array2[i];
				TrySetMember(tuple.Item1, tuple.Item2, tuple.Item3, GetDefaultValue(tuple.Item3), tuple.Item4);
			}
			try
			{
				if (typeFromHandle.GetField("userRPCCalls", BindingFlags.Instance | BindingFlags.NonPublic)?.GetValue(instance) is IDictionary dictionary)
				{
					dictionary.Clear();
				}
			}
			catch
			{
			}
			LoadBalancingClient networkingClient2 = PhotonNetwork.NetworkingClient;
			Hashtable val2 = new Hashtable();
			val2.Add((byte)0, (object)GorillaTagger.Instance.myVRRig.ViewID);
			RaiseEventOptions val3 = new RaiseEventOptions();
			val3.CachingOption = (EventCaching)6;
			val3.TargetActors = new int[1] { PhotonNetwork.LocalPlayer.ActorNumber };
			networkingClient2.OpRaiseEvent((byte)200, (object)val2, val3, SendOptions.SendReliable);
			if (Time.time > rpcDel)
			{
				try
				{
					rpcDel = Time.time + 0.47f;
					PhotonNetwork.RemoveBufferedRPCs(int.MaxValue, (string)null, (int[])null);
					PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
					PhotonNetwork.OpCleanActorRpcBuffer(PhotonNetwork.LocalPlayer.ActorNumber);
					PhotonNetwork.OpCleanRpcBuffer(GorillaTagger.Instance.myVRRig.GetView);
					((PhotonPeer)PhotonNetwork.NetworkingClient.LoadBalancingPeer).SendOutgoingCommands();
					Traverse val4 = Traverse.Create(typeof(PhotonNetwork));
					val4.Property("ResentReliableCommands", (object[])null).SetValue((object)0);
					PhotonNetwork.NetworkingClient.Service();
					PhotonNetwork.NetworkingClient.OpChangeGroups((byte[])null, new byte[4] { 1, 2, 3, 4 });
					((PhotonPeer)PhotonNetwork.NetworkingClient.LoadBalancingPeer).TrafficStatsReset();
					try
					{
						Type type2 = AppDomain.CurrentDomain.GetAssemblies().First((Assembly a) => a.GetName().Name == "Assembly-CSharp").GetType("RoomSystem");
						type2.GetMethod("OnPlayerLeftRoom", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(null, new object[1] { NetworkSystem.Instance.LocalPlayer });
					}
					catch
					{
					}
					try
					{
						NetSystemState val5 = (NetSystemState)0;
						PeerStateValue val6 = (PeerStateValue)0;
						((object)(*(NetSystemState*)(&val5))/*cast due to .constrained prefix*/).Equals((object)(NetSystemState)3);
						((object)(*(PeerStateValue*)(&val6))/*cast due to .constrained prefix*/).Equals((object)(PeerStateValue)3);
						RunViewUpdate();
					}
					catch
					{
					}
					PhotonNetwork.SendAllOutgoingCommands();
					try
					{
						if (typeof(PhotonNetwork).GetField("photonViewList", BindingFlags.Static | BindingFlags.NonPublic)?.GetValue(null) is IDictionary dictionary2)
						{
							ArrayList arrayList = new ArrayList();
							foreach (DictionaryEntry item in dictionary2)
							{
								object? value = item.Value;
								PhotonView val7 = (PhotonView)((value is PhotonView) ? value : null);
								if ((Object)(object)val7 != (Object)null && val7.IsMine && val7.isRuntimeInstantiated)
								{
									arrayList.Add(item.Key);
								}
							}
							foreach (object item2 in arrayList)
							{
								dictionary2.Remove(item2);
							}
						}
					}
					catch
					{
					}
				}
				catch
				{
				}
			}
			typeFromHandle.GetMethod("RefreshRPCs", BindingFlags.Instance | BindingFlags.NonPublic)?.Invoke(instance, null);
		}
		catch
		{
		}
	}

	private static void AntiRPCKicker()
	{
		for (int i = 0; i < 1300; i++)
		{
			ResendCachedRpc();
		}
		try
		{
			LoadBalancingPeer loadBalancingPeer = PhotonNetwork.NetworkingClient.LoadBalancingPeer;
			FieldInfo field = ((object)loadBalancingPeer).GetType().GetField("outgoingStreamQueue", BindingFlags.Instance | BindingFlags.NonPublic);
			if (field != null && field.GetValue(loadBalancingPeer) is IList { Count: >0 } list)
			{
				cachedSerializedRpc = list[list.Count - 1] as byte[];
			}
		}
		catch
		{
			cachedSerializedRpc = null;
		}
	}

	private static void ResendCachedRpc()
	{
		if (cachedSerializedRpc == null)
		{
			return;
		}
		try
		{
			LoadBalancingPeer loadBalancingPeer = PhotonNetwork.NetworkingClient.LoadBalancingPeer;
			Type type = ((object)loadBalancingPeer).GetType();
			(type.GetMethod("SendReliable", BindingFlags.Instance | BindingFlags.NonPublic) ?? type.GetMethod("SendUnreliable", BindingFlags.Instance | BindingFlags.NonPublic))?.Invoke(loadBalancingPeer, new object[1] { cachedSerializedRpc });
		}
		catch
		{
			SetTick(9999f);
		}
	}

	public static void SetTick(float tickMultiplier)
	{
		GameObject obj = GameObject.Find("PhotonMono");
		PhotonHandler val = ((obj != null) ? obj.GetComponent<PhotonHandler>() : null);
		if ((Object)(object)val != (Object)null)
		{
			Traverse.Create((object)val).Field("nextSendTickCountOnSerialize").SetValue((object)(int)(Time.realtimeSinceStartup * tickMultiplier));
			PhotonHandler.SendAsap = true;
		}
	}

	private static bool TrySetMember(Type type, object instance, string fieldName, object value, bool isStatic)
	{
		try
		{
			FieldInfo field = type.GetField(fieldName, (BindingFlags)((isStatic ? 8 : 4) | 0x10 | 0x20));
			if (field != null)
			{
				field.SetValue(instance, value);
				return true;
			}
			return false;
		}
		catch
		{
			return false;
		}
	}

	private static object GetDefaultValue(string fieldName)
	{
		if (fieldName.Contains("Max") || fieldName.Contains("Limit") || fieldName.Contains("Count"))
		{
			return int.MaxValue;
		}
		if (fieldName.Contains("userRPCCalls"))
		{
			return null;
		}
		if (fieldName.Contains("_sendReport"))
		{
			return false;
		}
		return null;
	}

	public static void RPCProtection()
	{
		AntiRPCKick();
	}

	public static object RunViewUpdate()
	{
		return typeof(PhotonNetwork).GetMethod("RunViewUpdate", BindingFlags.Static | BindingFlags.NonPublic)?.Invoke(null, null);
	}

	public static void InitializeAntiBanHelper()
	{
		if (initialized)
		{
			return;
		}
		try
		{
			Type typeFromHandle = typeof(PlayFabHttp);
			clearAllEventsMethod = typeFromHandle.GetMethod("ClearAllEvents", BindingFlags.Static | BindingFlags.Public);
			authContextField = typeof(PlayFabAuthenticationAPI).GetField("_authenticationContext", BindingFlags.Static | BindingFlags.NonPublic);
			staticPlayerField = typeof(PlayFabSettings).GetField("staticPlayer", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
			requestTimeoutField = typeof(PlayFabSettings).GetField("RequestTimeout", BindingFlags.Static | BindingFlags.Public);
			compressApiDataField = typeof(PlayFabSettings).GetField("CompressApiData", BindingFlags.Static | BindingFlags.Public);
			disableFocusTimeCollectionField = typeof(PlayFabSettings).GetField("DisableFocusTimeCollection", BindingFlags.Static | BindingFlags.Public);
			Type typeFromHandle2 = typeof(MonkeAgent);
			userRPCCallsField = typeFromHandle2.GetField("userRPCCalls", BindingFlags.Instance | BindingFlags.NonPublic);
			reportedPlayersField = typeFromHandle2.GetField("reportedPlayers", BindingFlags.Instance | BindingFlags.NonPublic);
			sendReportField = typeFromHandle2.GetField("_sendReport", BindingFlags.Instance | BindingFlags.NonPublic);
			suspiciousPlayerIdField = typeFromHandle2.GetField("_suspiciousPlayerId", BindingFlags.Instance | BindingFlags.NonPublic);
			suspiciousPlayerNameField = typeFromHandle2.GetField("_suspiciousPlayerName", BindingFlags.Instance | BindingFlags.NonPublic);
			suspiciousReasonField = typeFromHandle2.GetField("_suspiciousReason", BindingFlags.Instance | BindingFlags.NonPublic);
			Type typeFromHandle3 = typeof(PhotonNetwork);
			photonViewListField = typeFromHandle3.GetField("photonViewList", BindingFlags.Static | BindingFlags.NonPublic);
			cachedDataField = typeFromHandle3.GetField("cachedData", BindingFlags.Static | BindingFlags.NonPublic);
			monoRPCMethodsCacheField = typeFromHandle3.GetField("monoRPCMethodsCache", BindingFlags.Static | BindingFlags.NonPublic);
			Type typeFromHandle4 = typeof(LoadBalancingPeer);
			sentCountAllowanceField = typeFromHandle4.GetField("SentCountAllowance", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
			quickResendAttemptsField = typeFromHandle4.GetField("QuickResendAttempts", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
			outgoingStreamQueueField = typeFromHandle4.GetField("outgoingStreamQueue", BindingFlags.Instance | BindingFlags.NonPublic);
			initialized = true;
		}
		catch
		{
		}
	}

	public static void AntiBan()
	{
		InitializeAntiBanHelper();
		if (!PhotonNetwork.InRoom)
		{
			return;
		}
		try
		{
			MonkeAgent instance = MonkeAgent.instance;
			if ((Object)(object)instance != (Object)null)
			{
				instance.rpcErrorMax = int.MaxValue;
				instance.rpcCallLimit = int.MaxValue;
				instance.logErrorMax = int.MaxValue;
				userRPCCallsField?.SetValue(instance, new Dictionary<string, Dictionary<string, object>>());
				reportedPlayersField?.SetValue(instance, new List<string>());
				sendReportField?.SetValue(instance, false);
				suspiciousPlayerIdField?.SetValue(instance, "");
				suspiciousPlayerNameField?.SetValue(instance, "");
				suspiciousReasonField?.SetValue(instance, "");
			}
			PhotonNetwork.MaxResendsBeforeDisconnect = int.MaxValue;
			PhotonNetwork.QuickResends = int.MaxValue;
			PhotonNetwork.NetworkStatisticsEnabled = false;
			LoadBalancingClient networkingClient = PhotonNetwork.NetworkingClient;
			LoadBalancingPeer val = ((networkingClient != null) ? networkingClient.LoadBalancingPeer : null);
			if (val != null)
			{
				sentCountAllowanceField?.SetValue(val, int.MaxValue);
				quickResendAttemptsField?.SetValue(val, (byte)3);
				if (outgoingStreamQueueField?.GetValue(val) is IList list)
				{
					list.Clear();
				}
				((object)val).GetType().GetField("resentCommandsCount", BindingFlags.Instance | BindingFlags.NonPublic)?.SetValue(val, 0);
				((PhotonPeer)val).SendOutgoingCommands();
			}
			PhotonNetwork.SendAllOutgoingCommands();
			photonViewListField?.SetValue(null, Activator.CreateInstance(photonViewListField.FieldType));
			cachedDataField?.SetValue(null, new Dictionary<int, Dictionary<int, Queue<object[]>>>());
			monoRPCMethodsCacheField?.SetValue(null, new Dictionary<Type, List<MethodInfo>>());
			if (DateTime.UtcNow - lastAntiBanCall < antiBanInterval)
			{
				return;
			}
			lastAntiBanCall = DateTime.UtcNow;
			if (!PhotonNetwork.IsConnected)
			{
				authContextField?.SetValue(null, null);
				clearAllEventsMethod?.Invoke(null, null);
			}
			else
			{
				if (!PlayFabAuthenticationAPI.IsEntityLoggedIn())
				{
					return;
				}
				try
				{
					clearAllEventsMethod?.Invoke(null, null);
					requestTimeoutField?.SetValue(null, 30000);
					compressApiDataField?.SetValue(null, true);
					disableFocusTimeCollectionField?.SetValue(null, true);
					object? obj = staticPlayerField?.GetValue(null);
					PlayFabAuthenticationContext val2 = (PlayFabAuthenticationContext)((obj is PlayFabAuthenticationContext) ? obj : null);
					if (val2 != null)
					{
						val2.ForgetAllCredentials();
					}
					RPCFlush();
					return;
				}
				catch
				{
					return;
				}
			}
		}
		catch
		{
		}
	}

	public static void AntiReport()
	{
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			foreach (GorillaPlayerScoreboardLine allScoreboardLine in GorillaScoreboardTotalUpdater.allScoreboardLines)
			{
				if (allScoreboardLine.linePlayer != NetworkSystem.Instance.LocalPlayer)
				{
					continue;
				}
				Transform transform = ((Component)allScoreboardLine.reportButton).gameObject.transform;
				foreach (VRRig activeRig in VRRigCache.ActiveRigs)
				{
					if ((Object)(object)activeRig != (Object)(object)GorillaTagger.Instance.offlineVRRig)
					{
						float num = Vector3.Distance(activeRig.rightHandTransform.position, transform.position);
						float num2 = Vector3.Distance(activeRig.leftHandTransform.position, transform.position);
						float num3 = 0.5f;
						if (num < num3 || num2 < num3)
						{
							PhotonNetwork.Disconnect();
							NotifiLib.SendNotification("You Got Reported By a Player! You have been disconnected to avoid the report.");
						}
					}
				}
			}
		}
		catch
		{
		}
	}

	public static void NoTagFreeze()
	{
		GTPlayer.Instance.disableMovement = false;
	}

	public static void SetName(string name)
	{
		PhotonNetwork.LocalPlayer.NickName = name;
	}

	public static void KidnapParty()
	{
		PhotonNetworkController val = Object.FindObjectOfType<PhotonNetworkController>();
		val.AttemptToAutoJoinSpecificRoom("GETKIDNAPPED", (JoinType)4);
		SetName("Kidnapper");
	}

	public static void SendPartytoRandomBannedCode()
	{
		NotifiLib.SendNotification("Read the tooltip!");
		string[] array = new string[3] { "KKK", "HITLER", "MINI99" };
		string text = array[Random.Range(0, array.Length)];
		PhotonNetworkController val = Object.FindObjectOfType<PhotonNetworkController>();
		val.AttemptToAutoJoinSpecificRoom(text, (JoinType)4);
	}

	public static void KickParty()
	{
		Room currentRoom = PhotonNetwork.CurrentRoom;
		string roomCode = ((currentRoom != null) ? currentRoom.Name : null);
		if (!string.IsNullOrEmpty(roomCode))
		{
			((MonoBehaviour)GorillaTagger.Instance).StartCoroutine(Quarantine());
		}
		IEnumerator Quarantine()
		{
			yield return (object)new WaitForSeconds(1f);
			NotifiLib.SendNotification("Kicking Party... (Be patient, the kick may take longer based on network conditions)");
			PhotonNetworkController controller = Object.FindObjectOfType<PhotonNetworkController>();
			string randomCode = RandomCode();
			controller.AttemptToAutoJoinSpecificRoom(randomCode, (JoinType)4);
			while (!PhotonNetwork.InRoom || PhotonNetwork.CurrentRoom == null || PhotonNetwork.CurrentRoom.Name != randomCode)
			{
				yield return null;
			}
			NotifiLib.SendNotification("Kicking Party... (Be patient, the kick may take longer based on network conditions)");
			yield return (object)new WaitForSeconds(0.5f);
			controller.AttemptToAutoJoinSpecificRoom(roomCode, (JoinType)0);
			while (!PhotonNetwork.InRoom || PhotonNetwork.CurrentRoom == null || PhotonNetwork.CurrentRoom.Name != roomCode)
			{
				yield return null;
			}
			NotifiLib.SendNotification("Kicked Party!");
		}
	}

	public static void FlingOnGrab()
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		foreach (VRRig activeRig in VRRigCache.ActiveRigs)
		{
			TakeMyHand_HandLink leftHandLink = activeRig.leftHandLink;
			TakeMyHand_HandLink rightHandLink = activeRig.rightHandLink;
			if (leftHandLink.grabbedPlayer == NetworkSystem.Instance.LocalPlayer)
			{
				Transform transform = ((Component)GorillaTagger.Instance.offlineVRRig).transform;
				transform.position += Vector3.up * 50f;
				leftHandLink.BreakLink();
			}
			if (rightHandLink.grabbedPlayer == NetworkSystem.Instance.LocalPlayer)
			{
				Transform transform2 = ((Component)GorillaTagger.Instance.offlineVRRig).transform;
				transform2.position += Vector3.up * 50f;
				rightHandLink.BreakLink();
			}
		}
	}

	public static void FastFlingOnGrab()
	{
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		foreach (VRRig activeRig in VRRigCache.ActiveRigs)
		{
			TakeMyHand_HandLink leftHandLink = activeRig.leftHandLink;
			TakeMyHand_HandLink rightHandLink = activeRig.rightHandLink;
			if (leftHandLink.grabbedPlayer == NetworkSystem.Instance.LocalPlayer)
			{
				Transform transform = ((Component)GorillaTagger.Instance.offlineVRRig).transform;
				transform.position += Vector3.up * 500f;
				leftHandLink.BreakLink();
			}
			if (rightHandLink.grabbedPlayer == NetworkSystem.Instance.LocalPlayer)
			{
				Transform transform2 = ((Component)GorillaTagger.Instance.offlineVRRig).transform;
				transform2.position += Vector3.up * 500f;
				rightHandLink.BreakLink();
			}
		}
	}

	public static void InfoGun()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		MakeGun(Color.blue, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, (PrimitiveType)0, GTPlayer.Instance.RightHand.controllerTransform, liner: true, delegate
		{
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			//IL_0371: Unknown result type (might be due to invalid IL or missing references)
			//IL_0378: Expected O, but got Unknown
			//IL_038e: Unknown result type (might be due to invalid IL or missing references)
			//IL_03a4: Unknown result type (might be due to invalid IL or missing references)
			//IL_03f7: Unknown result type (might be due to invalid IL or missing references)
			//IL_0401: Unknown result type (might be due to invalid IL or missing references)
			//IL_0415: Unknown result type (might be due to invalid IL or missing references)
			//IL_041a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0080: Unknown result type (might be due to invalid IL or missing references)
			//IL_008b: Expected O, but got Unknown
			if (!((Object)(object)pointer == (Object)null))
			{
				VRRig val = null;
				Collider[] array = Physics.OverlapSphere(pointer.transform.position, 0.5f);
				Collider[] array2 = array;
				foreach (Collider val2 in array2)
				{
					VRRig componentInParent = ((Component)val2).GetComponentInParent<VRRig>();
					if ((Object)(object)componentInParent != (Object)null && !componentInParent.isLocal)
					{
						val = componentInParent;
						break;
					}
				}
				if (!((Object)val == (Object)null))
				{
					Player playerFromVRRig = RigShit.GetPlayerFromVRRig(val);
					string text = (FamousPlayers.ContainsKey(playerFromVRRig.UserId) ? FamousPlayers[playerFromVRRig.UserId] : "Not Famous");
					string platform = GetPlatform(val);
					string text2 = "Unknown";
					string text3 = "Unknown";
					string text4 = "Unknown";
					try
					{
						text2 = Traverse.Create((object)val).Field("turnType").GetValue()?.ToString() ?? "Unknown";
						text3 = Traverse.Create((object)val).Field("turnFactor").GetValue()?.ToString() ?? "Unknown";
						text4 = Traverse.Create((object)val).Field("currentFPS").GetValue()?.ToString() ?? Traverse.Create((object)val).Field("fps").GetValue()?.ToString() ?? "Unknown";
					}
					catch
					{
					}
					bool flag = playerFromVRRig.UserId == TargetUserId;
					string text5 = string.Concat("<color=cyan>Player Info Gun</color>\n", "Name: " + playerFromVRRig.NickName, "\n", "ID: " + playerFromVRRig.UserId, "\n", "Is Owner Of The Menu: " + flag, "\n", "Actor Number: " + playerFromVRRig.ActorNumber, "\n", "Color: " + Mathf.RoundToInt(val.playerColor.r * 9f) + ", " + Mathf.RoundToInt(val.playerColor.g * 9f) + ", " + Mathf.RoundToInt(val.playerColor.b * 9f), "\n", "Platform: " + platform, "\n", "FPS: " + text4, "\n", "Turn Type: " + text2, "\n", "Turn Speed: " + text3, "\n", "Is Master: " + playerFromVRRig.IsMasterClient, "\n", "Famous As: " + text, "\n");
					GameObject val3 = new GameObject("InfoLabel");
					val3.transform.localScale = new Vector3(0.07f, 0.07f, 0.07f);
					TextMesh orAddComponent = GTExt.GetOrAddComponent<TextMesh>(val3);
					orAddComponent.color = Color.white;
					orAddComponent.fontSize = 24;
					orAddComponent.fontStyle = (FontStyle)1;
					orAddComponent.characterSize = 0.1f;
					orAddComponent.anchor = (TextAnchor)4;
					orAddComponent.alignment = (TextAlignment)0;
					orAddComponent.text = text5;
					val3.transform.position = GTPlayer.Instance.RightHand.controllerTransform.position + new Vector3(0f, 0.18f, 0f);
					val3.transform.LookAt(VRRig.LocalRig.headMesh.transform);
					val3.transform.Rotate(0f, 180f, 0f);
					Object.Destroy((Object)(object)val3, Time.deltaTime);
				}
			}
		}, delegate
		{
			if (items.Count > 0)
			{
				items.Clear();
			}
		});
	}

	public static string GetPlatform(VRRig rig)
	{
		if ((Object)(object)rig == (Object)null)
		{
			return "Unknown";
		}
		try
		{
			int value = Traverse.Create((object)rig).Field("currentRankedSubTierPC").GetValue<int>();
			int value2 = Traverse.Create((object)rig).Field("currentRankedSubTierQuest").GetValue<int>();
			if (value > 0)
			{
				return "Steam";
			}
			if (value2 > 0)
			{
				return "Quest/Meta";
			}
			string text = string.Join("", rig.cosmeticSet.returnArray).ToLower();
			if (text.Contains("s. first login"))
			{
				return "Steam";
			}
			if (text.Contains("first login"))
			{
				return "Oculus";
			}
			return "Meta";
		}
		catch
		{
			return "Unknown";
		}
	}

	public static void SpecialNametag()
	{
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Expected O, but got Unknown
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		foreach (VRRig allRig in RigShit.GetAllRigs(i: false))
		{
			if (!((Object)(object)allRig == (Object)null) && !((Object)(object)allRig == (Object)(object)VRRig.LocalRig))
			{
				Player playerFromVRRig = RigShit.GetPlayerFromVRRig(allRig);
				if (playerFromVRRig != null && playerFromVRRig.UserId == TargetUserId)
				{
					GameObject val = new GameObject("SpecialNameTag");
					TextMesh val2 = val.AddComponent<TextMesh>();
					val2.text = "OWNER OF THE MENU";
					val2.color = Color.cyan;
					val2.fontSize = 30;
					val2.characterSize = 0.1f;
					val2.anchor = (TextAnchor)4;
					val2.alignment = (TextAlignment)1;
					val.transform.position = allRig.headMesh.transform.position + Vector3.up * 0.35f;
					val.transform.LookAt(VRRig.LocalRig.headMesh.transform);
					val.transform.Rotate(0f, 180f, 0f);
					Object.Destroy((Object)(object)val, Time.deltaTime);
				}
			}
		}
	}

	public static void SpecialNametag2()
	{
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Expected O, but got Unknown
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		foreach (VRRig allRig in RigShit.GetAllRigs(i: false))
		{
			if (!((Object)(object)allRig == (Object)null) && !((Object)(object)allRig == (Object)(object)VRRig.LocalRig))
			{
				Player playerFromVRRig = RigShit.GetPlayerFromVRRig(allRig);
				if (playerFromVRRig != null && playerFromVRRig.UserId == TargetUserId2)
				{
					GameObject val = new GameObject("SpecialNameTag2");
					TextMesh val2 = val.AddComponent<TextMesh>();
					val2.text = "BETA TESTER";
					val2.color = Color.purple;
					val2.fontSize = 30;
					val2.characterSize = 0.1f;
					val2.anchor = (TextAnchor)4;
					val2.alignment = (TextAlignment)1;
					val.transform.position = allRig.headMesh.transform.position + Vector3.up * 0.35f;
					val.transform.LookAt(VRRig.LocalRig.headMesh.transform);
					val.transform.Rotate(0f, 180f, 0f);
					Object.Destroy((Object)(object)val, Time.deltaTime);
				}
			}
		}
	}

	public static void HoverboardShooter()
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		if (WristMenu.gripDownR && Time.time > delay)
		{
			delay = Time.time + 0.3f;
			SendHoverBoard(((Component)GorillaTagger.Instance.rightHandTransform).transform.position, Quaternion.identity, ((Component)GorillaTagger.Instance.rightHandTransform).transform.forward * 12f);
		}
		if (WristMenu.gripDownL && Time.time > delay)
		{
			delay = Time.time + 0.3f;
			SendHoverBoard(((Component)GorillaTagger.Instance.leftHandTransform).transform.position, Quaternion.identity, ((Component)GorillaTagger.Instance.leftHandTransform).transform.forward * 12f);
		}
	}

	public static void SendHoverBoard(Vector3 pos, Quaternion rot, Vector3 vel)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		if (PhotonNetwork.IsConnected)
		{
			FreeHoverboardManager.instance.SendDropBoardRPC(pos, rot, vel, vel, Color.clear);
			RPCFlush();
		}
	}

	public static void Invisible()
	{
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		bool bbuttonDown = WristMenu.bbuttonDown;
		if (bbuttonDown && !lastBButtonState)
		{
			invisibleEnabled = !invisibleEnabled;
		}
		lastBButtonState = bbuttonDown;
		if (invisibleEnabled)
		{
			if (!wasInvisible)
			{
				((Component)VRRig.LocalRig).gameObject.SetActive(false);
				wasInvisible = true;
			}
			((Component)VRRig.LocalRig).transform.position = ((Component)GorillaTagger.Instance.bodyCollider).transform.position - Vector3.up * 99999f;
		}
		else if (wasInvisible)
		{
			((Component)VRRig.LocalRig).gameObject.SetActive(true);
			wasInvisible = false;
		}
	}

	public static void GhostMonke()
	{
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Expected O, but got Unknown
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Expected O, but got Unknown
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Expected O, but got Unknown
		bool abuttonDown = WristMenu.abuttonDown;
		if (abuttonDown && !lastAButtonState)
		{
			ghostEnabled = !ghostEnabled;
		}
		lastAButtonState = abuttonDown;
		if (ghostEnabled)
		{
			if (!wasFrozen)
			{
				frozenPosition = ((Component)VRRig.LocalRig).transform.position;
				Quaternion rotation = ((Component)VRRig.LocalRig).transform.rotation;
				frozenClone = new GameObject("FrozenClone");
				frozenClone.transform.SetPositionAndRotation(frozenPosition, rotation);
				SkinnedMeshRenderer[] componentsInChildren = ((Component)VRRig.LocalRig).GetComponentsInChildren<SkinnedMeshRenderer>();
				foreach (SkinnedMeshRenderer val in componentsInChildren)
				{
					if (!(((Object)((Component)val).gameObject).name == "gorilla_skl") && !(((Object)((Component)val).gameObject).name == "gorilla_nhd"))
					{
						GameObject val2 = new GameObject(((Object)((Component)val).gameObject).name);
						val2.transform.SetParent(frozenClone.transform, false);
						val2.transform.localPosition = ((Component)val).transform.localPosition;
						val2.transform.localRotation = ((Component)val).transform.localRotation;
						val2.transform.localScale = ((Component)val).transform.localScale;
						Mesh val3 = new Mesh();
						val.BakeMesh(val3);
						MeshFilter val4 = val2.AddComponent<MeshFilter>();
						val4.mesh = val3;
						MeshRenderer val5 = val2.AddComponent<MeshRenderer>();
						((Renderer)val5).sharedMaterials = ((Renderer)val).sharedMaterials;
					}
				}
				((Component)VRRig.LocalRig).gameObject.SetActive(false);
				wasFrozen = true;
			}
			((Component)VRRig.LocalRig).transform.position = frozenPosition;
			((Component)GorillaTagger.Instance.bodyCollider).transform.position = frozenPosition;
		}
		else if (wasFrozen)
		{
			if ((Object)(object)frozenClone != (Object)null)
			{
				Object.Destroy((Object)(object)frozenClone);
				frozenClone = null;
			}
			((Component)VRRig.LocalRig).gameObject.SetActive(true);
			wasFrozen = false;
		}
	}

	public static void SetGuardianGun()
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			NotifiLib.SendNotification("<color=red>Must be Master Client!</color>");
			return;
		}
		MakeGun(Color.green, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, (PrimitiveType)0, GTPlayer.Instance.RightHand.controllerTransform, liner: true, delegate
		{
			if (!((Object)(object)((RaycastHit)(ref raycastHit)).collider == (Object)null))
			{
				VRRig componentInParent = ((Component)((RaycastHit)(ref raycastHit)).collider).GetComponentInParent<VRRig>();
				if (!((Object)(object)componentInParent == (Object)null))
				{
					NetPlayer creator = componentInParent.Creator;
					if (creator != null)
					{
						foreach (GorillaGuardianZoneManager zoneManager in GorillaGuardianZoneManager.zoneManagers)
						{
							zoneManager.SetGuardian(creator);
						}
					}
				}
			}
		}, delegate
		{
		});
		RPCFlush();
	}

	public static void RemoveGuardianGun()
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			NotifiLib.SendNotification("<color=red>Must be Master Client!</color>");
			return;
		}
		MakeGun(Color.red, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, (PrimitiveType)0, GTPlayer.Instance.RightHand.controllerTransform, liner: true, delegate
		{
			if (!((Object)(object)((RaycastHit)(ref raycastHit)).collider == (Object)null))
			{
				VRRig componentInParent = ((Component)((RaycastHit)(ref raycastHit)).collider).GetComponentInParent<VRRig>();
				if (!((Object)(object)componentInParent == (Object)null))
				{
					NetPlayer creator = componentInParent.Creator;
					if (creator != null)
					{
						foreach (GorillaGuardianZoneManager zoneManager in GorillaGuardianZoneManager.zoneManagers)
						{
							if (zoneManager.CurrentGuardian == creator)
							{
								zoneManager.SetGuardian((NetPlayer)null);
							}
						}
					}
				}
			}
		}, delegate
		{
		});
		RPCFlush();
	}

	public static void RainbowColor()
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > colorChangerDelay)
		{
			colorChangerDelay = Time.time + 0.05f;
			ChangeColor(Color.HSVToRGB((float)Time.frameCount / 180f % 1f, 1f, 1f));
		}
	}

	public static void RandomColor()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		Color color = default(Color);
		((Color)(ref color))._002Ector(Random.value, Random.value, Random.value);
		ChangeColor(color);
	}

	public static void RandomStrobe()
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > randomStrobeDelay)
		{
			randomStrobeDelay = Time.time + 0.05f;
			ChangeColor(new Color(Random.value, Random.value, Random.value));
		}
	}

	public static void RainbowStrobe()
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		if (Time.time > rainbowStrobeDelay)
		{
			rainbowStrobeDelay = Time.time + 0.7f;
			ChangeColor(Color.HSVToRGB((float)Time.frameCount / 180f % 1f, 1f, 1f));
		}
	}

	public static void Set279Color()
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		ChangeColor(new Color(2f / 9f, 7f / 9f, 1f));
	}

	public static void SetColor(int r, int g, int b)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		ChangeColor(new Color((float)r / 9f, (float)g / 9f, (float)b / 9f));
	}

	public static CrittersManager GetCrittersManager()
	{
		return CrittersManager.instance;
	}

	public static void DespawnAllCritters()
	{
		if (PhotonNetwork.IsMasterClient)
		{
			CrittersManager crittersManager = GetCrittersManager();
			if ((Object)(object)crittersManager != (Object)null)
			{
				crittersManager.QueueDespawnAllCritters();
			}
		}
	}

	public static void MakeCrittersPeaceful()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			return;
		}
		CrittersManager crittersManager = GetCrittersManager();
		if ((Object)(object)crittersManager == (Object)null)
		{
			return;
		}
		foreach (CrittersActor crittersActor in crittersManager.crittersActors)
		{
			CrittersPawn val = (CrittersPawn)(object)((crittersActor is CrittersPawn) ? crittersActor : null);
			if (val != null)
			{
				val.currentState = (CreatureState)0;
			}
		}
	}

	public static void MakeCrittersEat()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			return;
		}
		CrittersManager crittersManager = GetCrittersManager();
		if ((Object)(object)crittersManager == (Object)null)
		{
			return;
		}
		foreach (CrittersActor crittersActor in crittersManager.crittersActors)
		{
			CrittersPawn val = (CrittersPawn)(object)((crittersActor is CrittersPawn) ? crittersActor : null);
			if (val != null)
			{
				val.currentState = (CreatureState)1;
			}
		}
	}

	public static void MakeCrittersRun()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			return;
		}
		CrittersManager crittersManager = GetCrittersManager();
		if ((Object)(object)crittersManager == (Object)null)
		{
			return;
		}
		foreach (CrittersActor crittersActor in crittersManager.crittersActors)
		{
			CrittersPawn val = (CrittersPawn)(object)((crittersActor is CrittersPawn) ? crittersActor : null);
			if (val != null)
			{
				val.currentState = (CreatureState)3;
			}
		}
	}

	public static void MakeCrittersSleep()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			return;
		}
		CrittersManager crittersManager = GetCrittersManager();
		if ((Object)(object)crittersManager == (Object)null)
		{
			return;
		}
		foreach (CrittersActor crittersActor in crittersManager.crittersActors)
		{
			CrittersPawn val = (CrittersPawn)(object)((crittersActor is CrittersPawn) ? crittersActor : null);
			if (val != null)
			{
				val.currentState = (CreatureState)5;
			}
		}
	}

	public static void SpawnFoodAtPlayer()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			return;
		}
		CrittersManager crittersManager = GetCrittersManager();
		if (!((Object)(object)crittersManager == (Object)null))
		{
			Vector3 position = ((Component)GTPlayer.Instance).transform.position + Vector3.up * 2f;
			CrittersActor val = crittersManager.SpawnActor((CrittersActorType)1, -1);
			if ((Object)(object)val != (Object)null)
			{
				((Component)val).transform.position = position;
			}
		}
	}

	public static void SpawnCageAtPlayer()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			return;
		}
		CrittersManager crittersManager = GetCrittersManager();
		if (!((Object)(object)crittersManager == (Object)null))
		{
			Vector3 position = ((Component)GTPlayer.Instance).transform.position + Vector3.up * 2f;
			CrittersActor val = crittersManager.SpawnActor((CrittersActorType)10, -1);
			if ((Object)(object)val != (Object)null)
			{
				((Component)val).transform.position = position;
			}
		}
	}

	public static void SpawnStunBombAtPlayer()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			return;
		}
		CrittersManager crittersManager = GetCrittersManager();
		if (!((Object)(object)crittersManager == (Object)null))
		{
			Vector3 position = ((Component)GTPlayer.Instance).transform.position + Vector3.up * 2f;
			CrittersActor val = crittersManager.SpawnActor((CrittersActorType)13, -1);
			if ((Object)(object)val != (Object)null)
			{
				((Component)val).transform.position = position;
			}
		}
	}

	public static void SpawnNoiseMakerAtPlayer()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			return;
		}
		CrittersManager crittersManager = GetCrittersManager();
		if (!((Object)(object)crittersManager == (Object)null))
		{
			Vector3 position = ((Component)GTPlayer.Instance).transform.position + Vector3.up * 2f;
			CrittersActor val = crittersManager.SpawnActor((CrittersActorType)16, -1);
			if ((Object)(object)val != (Object)null)
			{
				((Component)val).transform.position = position;
			}
		}
	}

	public static void SpawnStickyTrapAtPlayer()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			return;
		}
		CrittersManager crittersManager = GetCrittersManager();
		if (!((Object)(object)crittersManager == (Object)null))
		{
			Vector3 position = ((Component)GTPlayer.Instance).transform.position + Vector3.up * 2f;
			CrittersActor val = crittersManager.SpawnActor((CrittersActorType)17, -1);
			if ((Object)(object)val != (Object)null)
			{
				((Component)val).transform.position = position;
			}
		}
	}

	public static void TriggerMassStun()
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		if (PhotonNetwork.IsMasterClient)
		{
			CrittersManager crittersManager = GetCrittersManager();
			if (!((Object)(object)crittersManager == (Object)null))
			{
				Vector3 position = ((Component)GTPlayer.Instance).transform.position;
				crittersManager.TriggerEvent((CritterEvent)0, -1, position, Quaternion.identity);
			}
		}
	}

	public static void DespawnAllFood()
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Invalid comparison between Unknown and I4
		if (!PhotonNetwork.IsMasterClient)
		{
			return;
		}
		CrittersManager crittersManager = GetCrittersManager();
		if ((Object)(object)crittersManager == (Object)null)
		{
			return;
		}
		foreach (CrittersActor allActor in crittersManager.allActors)
		{
			if ((int)allActor.crittersActorType == 1 && ((Component)allActor).gameObject.activeSelf)
			{
				crittersManager.DespawnActor(allActor);
			}
		}
	}

	public static void DespawnAllTraps()
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Invalid comparison between Unknown and I4
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Invalid comparison between Unknown and I4
		if (!PhotonNetwork.IsMasterClient)
		{
			return;
		}
		CrittersManager crittersManager = GetCrittersManager();
		if ((Object)(object)crittersManager == (Object)null)
		{
			return;
		}
		foreach (CrittersActor allActor in crittersManager.allActors)
		{
			if (((int)allActor.crittersActorType == 17 || (int)allActor.crittersActorType == 10) && ((Component)allActor).gameObject.activeSelf)
			{
				crittersManager.DespawnActor(allActor);
			}
		}
	}

	public static void BringAllCritters()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			return;
		}
		CrittersManager crittersManager = GetCrittersManager();
		if ((Object)(object)crittersManager == (Object)null)
		{
			return;
		}
		Vector3 position = ((Component)GTPlayer.Instance).transform.position;
		foreach (CrittersActor crittersActor in crittersManager.crittersActors)
		{
			if (crittersActor is CrittersPawn)
			{
				((Component)crittersActor).transform.position = position + Vector3.up * 2f + Random.insideUnitSphere * 3f;
			}
		}
	}

	public static void GiantCritters()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			return;
		}
		CrittersManager crittersManager = GetCrittersManager();
		if ((Object)(object)crittersManager == (Object)null)
		{
			return;
		}
		foreach (CrittersActor crittersActor in crittersManager.crittersActors)
		{
			if (crittersActor is CrittersPawn)
			{
				((Component)crittersActor).transform.localScale = Vector3.one * 5f;
			}
		}
	}

	public static void TinyCritters()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			return;
		}
		CrittersManager crittersManager = GetCrittersManager();
		if ((Object)(object)crittersManager == (Object)null)
		{
			return;
		}
		foreach (CrittersActor crittersActor in crittersManager.crittersActors)
		{
			if (crittersActor is CrittersPawn)
			{
				((Component)crittersActor).transform.localScale = Vector3.one * 0.2f;
			}
		}
	}

	public static void ResetCritterSizes()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.IsMasterClient)
		{
			return;
		}
		CrittersManager crittersManager = GetCrittersManager();
		if ((Object)(object)crittersManager == (Object)null)
		{
			return;
		}
		foreach (CrittersActor crittersActor in crittersManager.crittersActors)
		{
			if (crittersActor is CrittersPawn)
			{
				((Component)crittersActor).transform.localScale = Vector3.one;
			}
		}
	}

	public static async void LaunchProj(Vector3 po, Vector3 v, string s, float mu = 1f, bool f = false)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		SnowballThrowable g = null;
		new Delay().D(0.4f, delegate
		{
			g = GetSnow(curprojb);
		});
		bool z = v != Vector3.zero;
		GTPlayer p = GTPlayer.Instance;
		Rigidbody i = GorillaTagger.Instance.rigidbody;
		if (po != Vector3.zero)
		{
			if (Vector3.Distance(po, ((Component)VRRig.LocalRig).transform.position) > 3f)
			{
				((Behaviour)VRRig.LocalRig).enabled = false;
				((Component)VRRig.LocalRig).transform.position = (((Object)lockedrig == (Object)null) ? po : ((Component)lockedrig).transform.position) + new Vector3(0f, 1f, 0f);
				DrawHandOrbs();
			}
			if (!((Behaviour)VRRig.LocalRig).enabled)
			{
				DrawHandOrbs();
				((Component)VRRig.LocalRig).transform.position = (((Object)lockedrig == (Object)null) ? po : ((Component)lockedrig).transform.position) + new Vector3(0f, 1f, 0f);
			}
		}
		if (!((Object)g != (Object)null))
		{
			return;
		}
		if (ogp == Vector3.zero && z)
		{
			Vector3 linearVelocity = i.linearVelocity;
			ogv = ((Vector3)(ref linearVelocity)).magnitude;
			linearVelocity = i.linearVelocity;
			Vector3 val;
			if (!(((Vector3)(ref linearVelocity)).sqrMagnitude > 1E-06f))
			{
				val = ((Component)GorillaTagger.Instance).transform.forward;
			}
			else
			{
				linearVelocity = i.linearVelocity;
				val = ((Vector3)(ref linearVelocity)).normalized;
			}
			ogd = val;
			ogp = ((Component)GTPlayer.Instance.bodyCollider).transform.position;
		}
		g.maxLinSpeed = float.MaxValue;
		if (curprojb == "Growing Snowball" && !IsEnabled("Auto Big Snowballs"))
		{
			AutoBigSnowballs();
		}
		if (z)
		{
			i.linearVelocity = ((Vector3)(ref v)).normalized * mu;
		}
		if (po != Vector3.zero)
		{
			((Component)g).gameObject.transform.position = po;
		}
		try
		{
			((HoldableObject)g).DropItemCleanup();
			if (!(ogp != Vector3.zero))
			{
				return;
			}
			if (!f || !((Behaviour)VRRig.LocalRig).enabled)
			{
				try
				{
					Vector3 adjustedPos = ogp - ((Component)GorillaTagger.Instance.bodyCollider).transform.position + ((Component)GorillaTagger.Instance).transform.position;
					p.TeleportTo(adjustedPos, ((Component)p).transform.rotation, false, false);
				}
				catch
				{
				}
			}
			i.linearVelocity = ogd * ogv;
			ogv = -1f;
			ogp = Vector3.zero;
		}
		catch
		{
		}
	}

	public static void ProjectileSpammer()
	{
		if (WristMenu.gripDownR)
		{
			new Delay().D(0.4f, delegate
			{
				//IL_0028: Unknown result type (might be due to invalid IL or missing references)
				//IL_0032: Unknown result type (might be due to invalid IL or missing references)
				SnowballThrowable snow = GetSnow(curprojb);
				if ((Object)(object)snow != (Object)null)
				{
					((Component)snow).gameObject.transform.position = GTPlayer.Instance.RightHand.controllerTransform.position;
				}
			});
		}
		else
		{
			if (!WristMenu.gripDownL)
			{
				return;
			}
			new Delay().D(0.4f, delegate
			{
				//IL_0028: Unknown result type (might be due to invalid IL or missing references)
				//IL_0032: Unknown result type (might be due to invalid IL or missing references)
				SnowballThrowable snow = GetSnow(curprojb);
				if ((Object)(object)snow != (Object)null)
				{
					((Component)snow).gameObject.transform.position = GTPlayer.Instance.LeftHand.controllerTransform.position;
				}
			});
		}
	}

	public static void SpawnProjInHand()
	{
		if (WristMenu.gripDownR)
		{
			new Delay().D(0.4f, delegate
			{
				//IL_0028: Unknown result type (might be due to invalid IL or missing references)
				//IL_0032: Unknown result type (might be due to invalid IL or missing references)
				SnowballThrowable snow = GetSnow(curprojb);
				if ((Object)(object)snow != (Object)null)
				{
					((Component)snow).gameObject.transform.position = GTPlayer.Instance.RightHand.controllerTransform.position;
				}
			});
		}
		else
		{
			if (!WristMenu.gripDownL)
			{
				return;
			}
			new Delay().D(0.4f, delegate
			{
				//IL_0028: Unknown result type (might be due to invalid IL or missing references)
				//IL_0032: Unknown result type (might be due to invalid IL or missing references)
				SnowballThrowable snow = GetSnow(curprojb);
				if ((Object)(object)snow != (Object)null)
				{
					((Component)snow).gameObject.transform.position = GTPlayer.Instance.LeftHand.controllerTransform.position;
				}
			});
		}
	}

	public static void LaunchProj2()
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		if (WristMenu.gripDownR)
		{
			LaunchProj(GTPlayer.Instance.RightHand.controllerTransform.position, GTPlayer.Instance.RightHand.controllerTransform.forward, curprojb, 50f, curprojb == "Growing Snowball");
		}
		if (WristMenu.gripDownL)
		{
			LaunchProj(GTPlayer.Instance.LeftHand.controllerTransform.position, GTPlayer.Instance.LeftHand.controllerTransform.forward, curprojb, 50f, curprojb == "Growing Snowball");
		}
	}

	public static void ProjGun()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		MakeGun(Color.blue, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, (PrimitiveType)0, GTPlayer.Instance.RightHand.controllerTransform, liner: true, delegate
		{
			new Delay().D(0.4f, delegate
			{
				//IL_002d: Unknown result type (might be due to invalid IL or missing references)
				SnowballThrowable snow = GetSnow(curprojb);
				if ((Object)(object)snow != (Object)null)
				{
					((Component)snow).gameObject.transform.position = pointer.transform.position;
				}
			});
		}, delegate
		{
		});
	}

	public static void LaunchProjectile()
	{
		if (WristMenu.gripDownR)
		{
			new Delay().D(0.4f, delegate
			{
				//IL_0028: Unknown result type (might be due to invalid IL or missing references)
				//IL_0032: Unknown result type (might be due to invalid IL or missing references)
				SnowballThrowable snow = GetSnow(curprojb);
				if ((Object)(object)snow != (Object)null)
				{
					((Component)snow).gameObject.transform.position = GTPlayer.Instance.RightHand.controllerTransform.position;
				}
			});
		}
		else
		{
			if (!WristMenu.gripDownL)
			{
				return;
			}
			new Delay().D(0.4f, delegate
			{
				//IL_0028: Unknown result type (might be due to invalid IL or missing references)
				//IL_0032: Unknown result type (might be due to invalid IL or missing references)
				SnowballThrowable snow = GetSnow(curprojb);
				if ((Object)(object)snow != (Object)null)
				{
					((Component)snow).gameObject.transform.position = GTPlayer.Instance.LeftHand.controllerTransform.position;
				}
			});
		}
	}

	public static SnowballThrowable GetSnow(string na)
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Expected O, but got Unknown
		SnowballThrowable val = null;
		try
		{
			GameObject val2 = (rightproj ? ((EquipmentInteractor)EquipmentInteractor.instance).rightHandHeldEquipment.gameObject : ((EquipmentInteractor)EquipmentInteractor.instance).leftHandHeldEquipment.gameObject);
			val2.TryGetComponent<SnowballThrowable>(ref val);
		}
		catch
		{
			val = null;
		}
		if ((Object)val != (Object)null)
		{
			return val;
		}
		SnowballMaker val3 = (rightproj ? SnowballMaker.rightHandInstance : SnowballMaker.leftHandInstance);
		val3.TryCreateSnowball(d[curprojb], ref val);
		return val;
	}

	public static void AutoBigSnowballs()
	{
		try
		{
			GrowingSnowballThrowable[] array = Object.FindObjectsByType<GrowingSnowballThrowable>((FindObjectsInactive)1, (FindObjectsSortMode)0);
			GrowingSnowballThrowable[] array2 = array;
			foreach (GrowingSnowballThrowable val in array2)
			{
				if (val.SizeLevel != 5)
				{
					((object)val).GetType().GetMethod(PhotonNetwork.InRoom ? "SetSizeLevel" : "GrowToMax", BindingFlags.Instance | BindingFlags.NonPublic)?.Invoke(val, new object[1] { 5 });
				}
			}
		}
		catch
		{
		}
	}

	public static void GrabProj()
	{
		if (!WristMenu.gripDownR && !WristMenu.gripDownL)
		{
			return;
		}
		new Delay().D(0.2f, delegate
		{
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_004c: Unknown result type (might be due to invalid IL or missing references)
			SnowballThrowable snow = GetSnow(curprojb);
			if ((Object)(object)snow != (Object)null)
			{
				Transform val = (WristMenu.gripDownR ? GTPlayer.Instance.RightHand.controllerTransform : GTPlayer.Instance.LeftHand.controllerTransform);
				((Component)snow).gameObject.transform.position = val.position;
			}
		});
	}

	public static void RandomBlockGun()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		MakeGun(CurrentGunColor, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, (PrimitiveType)0, GTPlayer.Instance.RightHand.controllerTransform, liner: true, delegate
		{
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Unknown result type (might be due to invalid IL or missing references)
			//IL_002e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0034: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			Vector3 position = (((Object)(object)((RaycastHit)(ref raycastHit)).collider != (Object)null) ? ((RaycastHit)(ref raycastHit)).point : ((Component)VRRig.LocalRig).transform.position);
			SpawnBlock(GetRandomId(), position, Quaternion.identity);
			RPCFlush();
		}, delegate
		{
		});
	}

	public static void UngrabbableBlockGun()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		MakeGun(CurrentGunColor, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, (PrimitiveType)0, GTPlayer.Instance.RightHand.controllerTransform, liner: true, delegate
		{
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_001d: Unknown result type (might be due to invalid IL or missing references)
			//IL_002e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0034: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			Vector3 position = (((Object)(object)((RaycastHit)(ref raycastHit)).collider != (Object)null) ? ((RaycastHit)(ref raycastHit)).point : ((Component)VRRig.LocalRig).transform.position);
			SpawnBlock(1858470402, position, Quaternion.identity);
			RPCFlush();
		}, delegate
		{
		});
	}

	public static void BlockIdGun()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		MakeGun(CurrentGunColor, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, (PrimitiveType)0, GTPlayer.Instance.RightHand.controllerTransform, liner: true, delegate
		{
			if (!((Object)(object)((RaycastHit)(ref raycastHit)).collider == (Object)null))
			{
				BuilderPiece componentInParent = ((Component)((RaycastHit)(ref raycastHit)).collider).GetComponentInParent<BuilderPiece>();
				if (!((Object)(object)componentInParent == (Object)null))
				{
					NotifiLib.SendNotification($"<color=cyan>Block ID:</color> {componentInParent.pieceId}");
				}
			}
		}, delegate
		{
		});
	}

	public static void DestroyBlockGun()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		MakeGun(CurrentGunColor, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, (PrimitiveType)0, GTPlayer.Instance.RightHand.controllerTransform, liner: true, delegate
		{
			//IL_004e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			if (PhotonNetwork.IsMasterClient && !((Object)(object)((RaycastHit)(ref raycastHit)).collider == (Object)null))
			{
				BuilderPiece componentInParent = ((Component)((RaycastHit)(ref raycastHit)).collider).GetComponentInParent<BuilderPiece>();
				if (!((Object)(object)componentInParent == (Object)null))
				{
					DestroyBlock(componentInParent.pieceId, ((Component)componentInParent).transform.position, ((Component)componentInParent).transform.rotation, PlaySfx: true);
					RPCFlush();
				}
			}
		}, delegate
		{
		});
	}

	public static void DestroyBlocksOnHandTouch()
	{
		if (PhotonNetwork.IsMasterClient && !((Object)(object)GorillaTagger.Instance == (Object)null))
		{
			Transform leftHandTransform = GorillaTagger.Instance.leftHandTransform;
			Transform rightHandTransform = GorillaTagger.Instance.rightHandTransform;
			if ((Object)(object)leftHandTransform != (Object)null)
			{
				DestroyNearbyBlocks(leftHandTransform);
			}
			if ((Object)(object)rightHandTransform != (Object)null)
			{
				DestroyNearbyBlocks(rightHandTransform);
			}
			RPCFlush();
		}
	}

	private static void DestroyNearbyBlocks(Transform hand)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		Collider[] array = Physics.OverlapSphere(hand.position, 0.2f);
		Collider[] array2 = array;
		foreach (Collider val in array2)
		{
			if (!((Object)(object)val == (Object)null))
			{
				BuilderPiece componentInParent = ((Component)val).GetComponentInParent<BuilderPiece>();
				if (!((Object)(object)componentInParent == (Object)null))
				{
					DestroyBlock(componentInParent.pieceId, ((Component)componentInParent).transform.position, ((Component)componentInParent).transform.rotation, PlaySfx: true);
				}
			}
		}
	}

	public static void Tracers()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Expected O, but got Unknown
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		Player[] playerListOthers = PhotonNetwork.PlayerListOthers;
		foreach (Player p in playerListOthers)
		{
			VRRig vRRigFromPlayer = RigShit.GetVRRigFromPlayer(p);
			GameObject val = new GameObject("Line");
			LineRenderer val2 = val.AddComponent<LineRenderer>();
			val2.startWidth = 0.01f;
			val2.endWidth = 0.01f;
			val2.positionCount = 2;
			val2.useWorldSpace = true;
			val2.SetPosition(0, GTPlayer.Instance.RightHand.controllerTransform.position);
			val2.SetPosition(1, ((Component)vRRigFromPlayer).transform.position);
			((Renderer)val2).material.shader = Shader.Find("GUI/Text Shader");
			val2.startColor = CurrentESPColor;
			val2.endColor = CurrentESPColor;
			Object.Destroy((Object)(object)val2, Time.deltaTime);
		}
	}

	public static void BoxESP()
	{
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Expected O, but got Unknown
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0263: Unknown result type (might be due to invalid IL or missing references)
		//IL_0287: Unknown result type (might be due to invalid IL or missing references)
		//IL_0294: Unknown result type (might be due to invalid IL or missing references)
		Player[] playerListOthers = PhotonNetwork.PlayerListOthers;
		foreach (Player p in playerListOthers)
		{
			VRRig vRRigFromPlayer = RigShit.GetVRRigFromPlayer(p);
			if (!((Object)(object)vRRigFromPlayer == (Object)null))
			{
				Vector3 position = ((Component)vRRigFromPlayer).transform.position;
				float num = 0.5f;
				float num2 = 0.7f;
				Vector3[] array = (Vector3[])(object)new Vector3[8]
				{
					position + new Vector3(0f - num, 0f - num2, 0f - num),
					position + new Vector3(num, 0f - num2, 0f - num),
					position + new Vector3(num, 0f - num2, num),
					position + new Vector3(0f - num, 0f - num2, num),
					position + new Vector3(0f - num, num2, 0f - num),
					position + new Vector3(num, num2, 0f - num),
					position + new Vector3(num, num2, num),
					position + new Vector3(0f - num, num2, num)
				};
				int[][] array2 = new int[12][]
				{
					new int[2] { 0, 1 },
					new int[2] { 1, 2 },
					new int[2] { 2, 3 },
					new int[2] { 3, 0 },
					new int[2] { 4, 5 },
					new int[2] { 5, 6 },
					new int[2] { 6, 7 },
					new int[2] { 7, 4 },
					new int[2] { 0, 4 },
					new int[2] { 1, 5 },
					new int[2] { 2, 6 },
					new int[2] { 3, 7 }
				};
				int[][] array3 = array2;
				foreach (int[] array4 in array3)
				{
					GameObject val = new GameObject("BoxEdge");
					LineRenderer val2 = val.AddComponent<LineRenderer>();
					val2.startWidth = 0.02f;
					val2.endWidth = 0.02f;
					val2.positionCount = 2;
					val2.useWorldSpace = true;
					val2.SetPosition(0, array[array4[0]]);
					val2.SetPosition(1, array[array4[1]]);
					((Renderer)val2).material.shader = Shader.Find("GUI/Text Shader");
					val2.startColor = CurrentESPColor;
					val2.endColor = CurrentESPColor;
					Object.Destroy((Object)(object)val, Time.deltaTime);
				}
			}
		}
	}

	public static string RandomCode()
	{
		string text = "";
		for (int i = 0; i < 5; i++)
		{
			text += "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"[Random.Range(0, "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".Length)];
		}
		return text;
	}

	public static void Becomenull()
	{
		SetName("null");
		SetColor(0, 0, 0);
	}

	public static void BecomeRUN()
	{
		SetName("RUN");
		SetColor(0, 0, 0);
	}

	public static void BecomePBBV()
	{
		SetName("PBBV");
		SetColor(0, 0, 0);
	}

	public static void BecomeDAISY09()
	{
		SetName("DAISY09");
		SetColor(0, 0, 0);
	}

	public static void BecomeJ3VU()
	{
		SetName("J3VU");
		SetColor(0, 0, 0);
	}

	public static void ButtonEmulation()
	{
		WristMenu.abuttonDown |= UnityInput.Current.GetKey((KeyCode)101);
		WristMenu.bbuttonDown |= UnityInput.Current.GetKey((KeyCode)114);
		WristMenu.xbuttonDown |= UnityInput.Current.GetKey((KeyCode)102);
		WristMenu.ybuttonDown |= UnityInput.Current.GetKey((KeyCode)103);
		WristMenu.gripDownL |= UnityInput.Current.GetKey((KeyCode)91);
		WristMenu.gripDownLFloat += (UnityInput.Current.GetKey((KeyCode)91) ? 1f : 0f);
		WristMenu.gripDownR |= UnityInput.Current.GetKey((KeyCode)93);
		WristMenu.gripDownRFloat += (UnityInput.Current.GetKey((KeyCode)93) ? 1f : 0f);
		WristMenu.triggerDownR |= UnityInput.Current.GetKey((KeyCode)61);
		WristMenu.triggerDownRFloat += (UnityInput.Current.GetKey((KeyCode)61) ? 1f : 0f);
		WristMenu.triggerDownL |= UnityInput.Current.GetKey((KeyCode)45);
		WristMenu.triggerDownLFloat += (UnityInput.Current.GetKey((KeyCode)45) ? 1f : 0f);
	}

	public static void MyPreset()
	{
		FPSPage = true;
		change4 = 2;
		Changedisconnect();
		change7 = 2;
		Changepagebutton();
		change10 = 7;
		ThemeChangerV1();
		change11 = 0;
		ThemeChangerV2();
		change12 = 6;
		ThemeChangerV3();
		change13 = 6;
		ThemeChangerV4();
		change14 = 2;
		ThemeChangerV5();
		change15 = 1;
		ThemeChangerV6();
		change16 = 6;
		ThemeChangerV7();
		DisableButton("My Personal Preset");
	}

	public static void DisconnectLT()
	{
		if (PhotonNetwork.InRoom && WristMenu.triggerDownL)
		{
			PhotonNetwork.Disconnect();
		}
	}

	public static void DisconnectRT()
	{
		if (PhotonNetwork.InRoom && WristMenu.triggerDownR)
		{
			PhotonNetwork.Disconnect();
		}
	}

	public static void GhostMode()
	{
		EnableButton("Platforms (LG) (RG)");
		EnableButton("NoClip (RT)");
		EnableButton("Invisible Monke (B)");
		EnableButton("Ghost Monke (A)");
		EnableButton("No Tag Freeze");
	}

	public static void DisableGhostMode()
	{
		DisableButton("Platforms (LG) (RG)");
		DisableButton("NoClip (RT)");
		DisableButton("Invisible Monke (B)");
		DisableButton("Ghost Monke (A)");
		DisableButton("No Tag Freeze");
	}

	public static void UnloadMenu()
	{
		WristMenu.DestroyMenu();
	}

	public static void DisableAllButtons(params string[] excluded)
	{
		HashSet<string> hashSet = new HashSet<string>(excluded);
		List<List<ButtonInfo>> list = new List<List<ButtonInfo>>
		{
			WristMenu.buttons,
			WristMenu.settingsbuttons,
			WristMenu.CatButtons1,
			WristMenu.CatButtons2,
			WristMenu.CatButtons3,
			WristMenu.CatButtons4,
			WristMenu.CatButtons5,
			WristMenu.CatButtons6,
			WristMenu.CatButtons7,
			WristMenu.CatButtons8,
			WristMenu.CatButtons9,
			WristMenu.CatButtons10,
			WristMenu.CatButtons11
		};
		foreach (List<ButtonInfo> item in list)
		{
			foreach (ButtonInfo item2 in item)
			{
				if (!hashSet.Contains(item2.buttonText))
				{
					item2.enabled = false;
				}
			}
		}
		WristMenu.DestroyMenu();
		WristMenu.instance.Draw();
	}

	public static void Panic()
	{
		DisableAllButtons("NameTag 1", "NameTag 2", "master check", "button emulation");
	}

	public static void RPCFlush()
	{
		if (!PhotonNetwork.InRoom)
		{
			return;
		}
		try
		{
			MonkeAgent instance = MonkeAgent.instance;
			if ((Object)(object)instance == (Object)null)
			{
				return;
			}
			instance.rpcCallLimit = int.MaxValue;
			instance.rpcErrorMax = int.MaxValue;
			instance.logErrorMax = int.MaxValue;
			FieldInfo field = ((object)instance).GetType().GetField("gravityFactorOptionSelection", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
			if (field != null)
			{
				field.SetValue(instance, float.MaxValue);
			}
			VRRig component = ((Component)GTPlayer.Instance).GetComponent<VRRig>();
			if ((Object)(object)component != (Object)null)
			{
				PhotonNetwork.RemoveBufferedRPCs(((Component)component).GetComponent<PhotonView>().ViewID, (string)null, (int[])null);
			}
			PhotonNetwork.OpCleanActorRpcBuffer(PhotonNetwork.LocalPlayer.ActorNumber);
			PhotonNetwork.SendAllOutgoingCommands();
			try
			{
				instance.OnPlayerLeftRoom(NetworkSystem.Instance.LocalPlayer);
			}
			catch
			{
			}
		}
		catch
		{
		}
	}

	public static void MakeGun(Color color, Vector3 pointersize, float linesize, PrimitiveType pointershape, Transform arm, bool liner, Action shit, Action shit1)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Expected O, but got Unknown
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e5: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)arm == (Object)(object)GTPlayer.Instance.RightHand.controllerTransform)
		{
			hand = WristMenu.gripDownR;
			hand1 = WristMenu.triggerDownR;
		}
		else if ((Object)(object)arm == (Object)(object)GTPlayer.Instance.LeftHand.controllerTransform)
		{
			hand = WristMenu.gripDownL;
			hand1 = WristMenu.triggerDownL;
		}
		bool flag = Mouse.current != null && (Mouse.current.leftButton.isPressed || Mouse.current.rightButton.isPressed);
		if (hand || flag)
		{
			Physics.Raycast(arm.position, -arm.up, ref raycastHit);
			if ((Object)(object)pointer == (Object)null)
			{
				pointer = GameObject.CreatePrimitive(pointershape);
			}
			pointer.transform.localScale = pointersize;
			pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			pointer.transform.position = ((RaycastHit)(ref raycastHit)).point;
			pointer.GetComponent<Renderer>().material.color = color;
			if (liner)
			{
				GameObject val = new GameObject("Line");
				Line = val.AddComponent<LineRenderer>();
				((Renderer)Line).material.shader = Shader.Find("GUI/Text Shader");
				Line.startWidth = linesize;
				Line.endWidth = linesize;
				Line.startColor = color;
				Line.endColor = color;
				Line.positionCount = 2;
				Line.useWorldSpace = true;
				Line.SetPosition(0, arm.position);
				Line.SetPosition(1, pointer.transform.position);
				Object.Destroy((Object)(object)val, Time.deltaTime);
			}
			Object.Destroy((Object)(object)pointer.GetComponent<BoxCollider>());
			Object.Destroy((Object)(object)pointer.GetComponent<Rigidbody>());
			Object.Destroy((Object)(object)pointer.GetComponent<Collider>());
			if (hand1 || Mouse.current.leftButton.isPressed)
			{
				try
				{
					shit?.Invoke();
					return;
				}
				catch
				{
					return;
				}
			}
			shit1?.Invoke();
		}
		else if ((Object)(object)pointer != (Object)null)
		{
			Object.Destroy((Object)(object)pointer);
			pointer = null;
		}
	}

	public static void ExampleOnHowToUseGunLib()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		MakeGun(CurrentGunColor, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, (PrimitiveType)0, GTPlayer.Instance.RightHand.controllerTransform, liner: true, delegate
		{
			//IL_001a: Unknown result type (might be due to invalid IL or missing references)
			//IL_002e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Unknown result type (might be due to invalid IL or missing references)
			GameObject.Find("Floating Bug Holdable").transform.position = pointer.transform.position + new Vector3(0f, 0.25f, 0f);
		}, delegate
		{
		});
	}

	public static void ExampleOnHowToUseGunLibV2()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		MakeGun(CurrentGunColor, new Vector3(0.15f, 0.15f, 0.15f), 0.025f, (PrimitiveType)0, GTPlayer.Instance.RightHand.controllerTransform, liner: true, delegate
		{
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_003f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Unknown result type (might be due to invalid IL or missing references)
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = false;
			((Component)GorillaTagger.Instance.offlineVRRig).transform.position = pointer.transform.position + new Vector3(0f, 0.3f, 0f);
		}, delegate
		{
			((Behaviour)GorillaTagger.Instance.offlineVRRig).enabled = true;
		});
	}

	public static void RestartGame()
	{
		Process.Start("steam://rungameid/1533390");
		Application.Quit();
	}

	public static void QuitGame()
	{
		Application.Quit();
	}

	public static void MenuDiscord()
	{
		Process.Start(new ProcessStartInfo
		{
			FileName = "https://discord.gg/ScfqS97HWG",
			UseShellExecute = true
		});
	}

	public static void DisableAFKKick()
	{
		PhotonNetworkController val = Object.FindObjectOfType<PhotonNetworkController>();
		val.disableAFKKick = true;
	}

	public static void EnableAFKKick()
	{
		PhotonNetworkController val = Object.FindObjectOfType<PhotonNetworkController>();
		val.disableAFKKick = false;
	}

	public static void SoundSpammer(int num)
	{
		if ((((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || ((ControllerInputPoller)ControllerInputPoller.instance).leftGrab) && Time.time > delay)
		{
			delay = Time.time + 0.1f;
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlayHandTap", (RpcTarget)0, new object[3] { num, false, 999999f });
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(num, false, 999999f);
			}
		}
		RPCFlush();
	}

	public static void BassSoundSpam()
	{
		SoundSpammer(68);
	}

	public static void MetalSoundSpam()
	{
		SoundSpammer(18);
	}

	public static void WolfSoundSpam()
	{
		SoundSpammer(195);
	}

	public static void CatSoundSpam()
	{
		SoundSpammer(236);
	}

	public static void TurkeySoundSpam()
	{
		SoundSpammer(83);
	}

	public static void FrogSoundSpam()
	{
		SoundSpammer(91);
	}

	public static void BeeSoundSpam()
	{
		SoundSpammer(191);
	}

	public static void SqueakSoundSpam()
	{
		SoundSpammer(215);
	}

	public static void EarrapeSoundSpam()
	{
		SoundSpammer(215);
	}

	public static void DingSoundSpam()
	{
		SoundSpammer(244);
	}

	public static void BigCrystalSoundSpam()
	{
		SoundSpammer(213);
	}

	public static void PanSoundSpam()
	{
		SoundSpammer(248);
	}

	public static void AK47SoundSpam()
	{
		SoundSpammer(203);
	}

	public static void TickSoundSpam()
	{
		SoundSpammer(148);
	}

	public static void PianoSoundSpam()
	{
		if ((((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || ((ControllerInputPoller)ControllerInputPoller.instance).leftGrab) && Time.time > delay)
		{
			delay = Time.time + 0.1f;
			int num = Random.Range(295, 308);
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlayHandTap", (RpcTarget)0, new object[3] { num, false, 999999f });
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(num, false, 999999f);
			}
		}
		RPCFlush();
	}

	public static void RandomSoundSpam()
	{
		if ((((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || ((ControllerInputPoller)ControllerInputPoller.instance).leftGrab) && Time.time > delay)
		{
			delay = Time.time + 0.1f;
			int num = Random.Range(0, 350);
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlayHandTap", (RpcTarget)0, new object[3] { num, false, 999999f });
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(num, false, 999999f);
			}
		}
		RPCFlush();
	}

	public static void CrystalSoundSpam()
	{
		int[] array = new int[5] { 213, 214, 215, 216, 217 };
		if ((((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || ((ControllerInputPoller)ControllerInputPoller.instance).leftGrab) && Time.time > delay)
		{
			delay = Time.time + 0.15f;
			int num = array[Random.Range(0, array.Length)];
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlayHandTap", (RpcTarget)0, new object[3] { num, false, 999999f });
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(num, false, 999999f);
			}
		}
		RPCFlush();
	}

	public static void SirenSoundSpam()
	{
		int[] array = new int[4] { 250, 251, 252, 253 };
		if ((((ControllerInputPoller)ControllerInputPoller.instance).rightGrab || ((ControllerInputPoller)ControllerInputPoller.instance).leftGrab) && Time.time > delay)
		{
			delay = Time.time + 0.2f;
			int num = array[Random.Range(0, array.Length)];
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlayHandTap", (RpcTarget)0, new object[3] { num, false, 999999f });
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(num, false, 999999f);
			}
		}
		RPCFlush();
	}

	public static bool IsTagged(VRRig rig)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Expected O, but got Unknown
		//IL_0023: Expected O, but got Unknown
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Expected O, but got Unknown
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Expected O, but got Unknown
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Expected O, but got Unknown
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_025e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f0: Unknown result type (might be due to invalid IL or missing references)
		GorillaGameManager instance = GorillaGameManager.instance;
		string text = FindTaggedName(rig);
		bool flag = (Object)rig != (Object)RigShit.GetOwnVRRig();
		bool enabled = ((Behaviour)RigShit.GetOwnVRRig()).enabled;
		if (IsGameMode((GameModeType)1))
		{
			GorillaTagManager val = (GorillaTagManager)instance;
			bool flag2 = text == "LAVA MONKE" || text == "ROCK MONKE";
			return (val.currentInfected.Contains(rig.Creator) || val.currentIt == rig.Creator) && (flag ? flag2 : (!enabled || (enabled && flag2)));
		}
		if (IsGameMode((GameModeType)5))
		{
			GorillaFreezeTagManager val2 = (GorillaFreezeTagManager)instance;
			bool flag3 = text == "ICE" || text == "FROZEN";
			return (((GorillaTagManager)val2).currentInfected.Contains(rig.Creator) || val2.currentFrozen.ContainsKey(rig.Creator)) && (flag ? flag3 : (!enabled || (enabled && flag3)));
		}
		if (IsGameMode((GameModeType)10))
		{
			GorillaTagCompetitiveManager val3 = (GorillaTagCompetitiveManager)instance;
			bool flag4 = text == "LAVA MONKE" || text == "ROCK MONKE";
			return (((GorillaTagManager)val3).currentInfected.Contains(rig.Creator) || ((GorillaTagManager)val3).currentIt == rig.Creator) && (flag ? flag4 : (!enabled || (enabled && flag4)));
		}
		if (IsGameMode((GameModeType)11))
		{
			SuperInfectionGame instance2 = SuperInfectionGame.instance;
			bool flag5 = text == "LAVA MONKE" || text == "ROCK MONKE";
			return (((GorillaTagManager)instance2).currentInfected.Contains(rig.Creator) || ((GorillaTagManager)instance2).currentIt == rig.Creator) && (flag ? flag5 : (!enabled || (enabled && flag5)));
		}
		if (IsGameMode((GameModeType)9))
		{
			bool flag6 = text == "PROP";
			return ((GorillaTagManager)(GorillaPropHuntGameManager)instance).currentInfected.Contains(rig.Creator) && (flag ? flag6 : (!enabled || (enabled && flag6)));
		}
		if (IsGameMode((GameModeType)2))
		{
			bool flag7 = text == "HUNTED";
			return ((GorillaHuntManager)instance).currentHunted.Contains(rig.Creator) && (flag ? flag7 : (!enabled || (enabled && flag7)));
		}
		if (IsGameMode((GameModeType)8))
		{
			bool flag8 = text == "GUARDIAN";
			return ((GorillaGuardianManager)instance).IsPlayerGuardian(rig.Creator) && (flag ? flag8 : (!enabled || (enabled && flag8)));
		}
		if (IsGameMode((GameModeType)3))
		{
			bool flag9 = text == "KILLED";
			return ((GorillaPaintbrawlManager)instance).GetPlayerLives(rig.Creator) == 0 && (flag ? flag9 : (!enabled || (enabled && flag9)));
		}
		return false;
	}

	public static string FindTaggedName(VRRig rig)
	{
		string name = ((Object)((Renderer)rig.mainSkin).material).name;
		if (IsGameMode((GameModeType)1) || IsGameMode((GameModeType)10) || IsGameMode((GameModeType)11))
		{
			if (name.Contains("fected"))
			{
				return "LAVA MONKE";
			}
			if (name.Contains("It"))
			{
				return "ROCK MONKE";
			}
		}
		else
		{
			if (IsGameMode((GameModeType)9) && name.Contains("PropHunt"))
			{
				return "PROP";
			}
			if (IsGameMode((GameModeType)2) && name.Contains("ice (Instance)"))
			{
				return "HUNTED";
			}
			if (IsGameMode((GameModeType)5))
			{
				if (name.Contains("Ice_Body"))
				{
					return "ICE";
				}
				if (rig.iceCubeLeft.activeSelf)
				{
					return "FROZEN";
				}
			}
			else if (IsGameMode((GameModeType)8))
			{
				foreach (GorillaGuardianZoneManager zoneManager in GorillaGuardianZoneManager.zoneManagers)
				{
					if (zoneManager.IsPlayerGuardian(rig.Creator))
					{
						return "GUARDIAN";
					}
				}
			}
			else if (IsGameMode((GameModeType)3))
			{
				if (name.Contains("paintsplatter"))
				{
					return "KILLED";
				}
				if (name.Contains("stunned"))
				{
					return "STUNNED";
				}
				if (name.Contains("It"))
				{
					return "HIT";
				}
			}
		}
		return "UNTAGGED";
	}

	public static bool IsGameMode(GameModeType t)
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		if (!PhotonNetwork.InRoom)
		{
			return false;
		}
		return GorillaGameManager.instance.GameType() == t;
	}

	public static void TeleportPlayer(Vector3 pos)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = ((Component)GorillaTagger.Instance).transform.position - ((Component)GorillaTagger.Instance.bodyCollider).transform.position;
		GTPlayer.Instance.TeleportTo(pos + val, ((Component)GTPlayer.Instance).transform.rotation, false, false);
	}

	public static float GetNotificationDelaySeconds()
	{
		return (float)NotificationDecayTime * 0.02f;
	}

	public static void ChangeColor(Color color, object target = null)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0182: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		PlayerPrefs.SetFloat("redValue", Mathf.Clamp(color.r, 0f, 1f));
		PlayerPrefs.SetFloat("greenValue", Mathf.Clamp(color.g, 0f, 1f));
		PlayerPrefs.SetFloat("blueValue", Mathf.Clamp(color.b, 0f, 1f));
		GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
		PlayerPrefs.Save();
		try
		{
			if (target != null)
			{
				NetPlayer val = (NetPlayer)((target is NetPlayer) ? target : null);
				if (val == null)
				{
					if (target is RpcTarget val2)
					{
						GorillaTagger.Instance.myVRRig.SendRPC("RPC_InitializeNoobMaterial", val2, new object[3] { color.r, color.g, color.b });
					}
				}
				else
				{
					GorillaTagger.Instance.myVRRig.SendRPC("RPC_InitializeNoobMaterial", val, new object[3] { color.r, color.g, color.b });
				}
			}
			else
			{
				GorillaTagger.Instance.myVRRig.SendRPC("RPC_InitializeNoobMaterial", (RpcTarget)0, new object[3] { color.r, color.g, color.b });
			}
			AntiRPCKick();
			RPCProtection();
		}
		catch
		{
		}
	}

	public static bool IsEnabled(string n)
	{
		return GetButton(n).enabled == true;
	}

	public static bool IsEnabled(ButtonInfo b)
	{
		return b.enabled == true;
	}

	private static float NotiDelay()
	{
		return 1.2f;
	}

	public static void Save1()
	{
		List<string> list = new List<string>();
		foreach (ButtonInfo item in WristMenu.CatButtons1)
		{
			if (item.enabled == true)
			{
				list.Add(item.buttonText);
			}
		}
		foreach (ButtonInfo item2 in WristMenu.CatButtons2)
		{
			if (item2.enabled == true)
			{
				list.Add(item2.buttonText);
			}
		}
		foreach (ButtonInfo item3 in WristMenu.CatButtons3)
		{
			if (item3.enabled == true)
			{
				list.Add(item3.buttonText);
			}
		}
		foreach (ButtonInfo item4 in WristMenu.CatButtons4)
		{
			if (item4.enabled == true)
			{
				list.Add(item4.buttonText);
			}
		}
		foreach (ButtonInfo item5 in WristMenu.CatButtons5)
		{
			if (item5.enabled == true)
			{
				list.Add(item5.buttonText);
			}
		}
		foreach (ButtonInfo item6 in WristMenu.CatButtons6)
		{
			if (item6.enabled == true)
			{
				list.Add(item6.buttonText);
			}
		}
		foreach (ButtonInfo item7 in WristMenu.CatButtons7)
		{
			if (item7.enabled == true)
			{
				list.Add(item7.buttonText);
			}
		}
		foreach (ButtonInfo item8 in WristMenu.CatButtons8)
		{
			if (item8.enabled == true)
			{
				list.Add(item8.buttonText);
			}
		}
		foreach (ButtonInfo item9 in WristMenu.CatButtons9)
		{
			if (item9.enabled == true)
			{
				list.Add(item9.buttonText);
			}
		}
		foreach (ButtonInfo item10 in WristMenu.CatButtons10)
		{
			if (item10.enabled == true)
			{
				list.Add(item10.buttonText);
			}
		}
		File.WriteAllLines(WristMenu.FolderName + "\\Saved_Buttons.txt", list);
		NotifiLib.SendNotification("<color=white>[</color><color=blue>SAVE</color><color=white>]</color> <color=white>Saved Buttons Successfully!</color>");
	}

	public static void Load1()
	{
		string[] array = File.ReadAllLines(WristMenu.FolderName + "\\Saved_Buttons.txt");
		string[] array2 = array;
		foreach (string text in array2)
		{
			foreach (ButtonInfo item in WristMenu.CatButtons1)
			{
				if (item.buttonText == text)
				{
					item.enabled = true;
				}
			}
			foreach (ButtonInfo item2 in WristMenu.CatButtons2)
			{
				if (item2.buttonText == text)
				{
					item2.enabled = true;
				}
			}
			foreach (ButtonInfo item3 in WristMenu.CatButtons3)
			{
				if (item3.buttonText == text)
				{
					item3.enabled = true;
				}
			}
			foreach (ButtonInfo item4 in WristMenu.CatButtons4)
			{
				if (item4.buttonText == text)
				{
					item4.enabled = true;
				}
			}
			foreach (ButtonInfo item5 in WristMenu.CatButtons5)
			{
				if (item5.buttonText == text)
				{
					item5.enabled = true;
				}
			}
			foreach (ButtonInfo item6 in WristMenu.CatButtons6)
			{
				if (item6.buttonText == text)
				{
					item6.enabled = true;
				}
			}
			foreach (ButtonInfo item7 in WristMenu.CatButtons7)
			{
				if (item7.buttonText == text)
				{
					item7.enabled = true;
				}
			}
			foreach (ButtonInfo item8 in WristMenu.CatButtons8)
			{
				if (item8.buttonText == text)
				{
					item8.enabled = true;
				}
			}
			foreach (ButtonInfo item9 in WristMenu.CatButtons9)
			{
				if (item9.buttonText == text)
				{
					item9.enabled = true;
				}
			}
			foreach (ButtonInfo item10 in WristMenu.CatButtons10)
			{
				if (item10.buttonText == text)
				{
					item10.enabled = true;
				}
			}
		}
		NotifiLib.SendNotification("<color=white>[</color><color=blue>LOAD</color><color=white>]</color> <color=white>Loaded Buttons Successfully!</color>");
	}

	public static void Save()
	{
		List<string> list = new List<string>();
		foreach (ButtonInfo settingsbutton in WristMenu.settingsbuttons)
		{
			if (settingsbutton.enabled == true && settingsbutton.buttonText != "Save Settings")
			{
				list.Add(settingsbutton.buttonText);
			}
		}
		File.WriteAllLines(WristMenu.FolderName + "\\Saved_Settings.txt", list);
		string text = change1 + "\n" + change2 + "\n" + change3 + "\n" + change4 + "\n" + change6 + "\n" + change7 + "\n" + change8 + "\n" + change9 + "\n" + change10 + "\n" + change11 + "\n" + change12 + "\n" + change13 + "\n" + change14 + "\n" + change15 + "\n" + change16;
		File.WriteAllText(WristMenu.FolderName + "/Saved_Settings2.txt", text.ToString());
		NotifiLib.SendNotification("<color=white>[</color><color=blue>SAVE</color><color=white>]</color> <color=white>Saved Settings Successfully!</color>");
	}

	public static void Load()
	{
		string[] array = File.ReadAllLines(WristMenu.FolderName + "\\Saved_Settings.txt");
		string[] array2 = array;
		foreach (string text in array2)
		{
			foreach (ButtonInfo settingsbutton in WristMenu.settingsbuttons)
			{
				if (settingsbutton.buttonText == text)
				{
					settingsbutton.enabled = true;
				}
			}
		}
		try
		{
			string text2 = File.ReadAllText(WristMenu.FolderName + "/Saved_Settings2.txt");
			string[] array3 = text2.Split(new string[1] { "\n" }, StringSplitOptions.None);
			change1 = int.Parse(array3[0]) - 1;
			Changeplat();
			change2 = int.Parse(array3[1]) - 1;
			Changenoti();
			change3 = int.Parse(array3[2]) - 1;
			ChangeFPS();
			change4 = int.Parse(array3[3]) - 1;
			Changedisconnect();
			change6 = int.Parse(array3[4]) - 1;
			Changemenu();
			change7 = int.Parse(array3[5]) - 1;
			Changepagebutton();
			change8 = int.Parse(array3[6]) - 1;
			ChangeOrbColor();
			change9 = int.Parse(array3[7]) - 1;
			ChangeVisualColor();
			change10 = int.Parse(array3[8]) - 1;
			ThemeChangerV1();
			change11 = int.Parse(array3[9]) - 1;
			ThemeChangerV2();
			change12 = int.Parse(array3[10]) - 1;
			ThemeChangerV3();
			change13 = int.Parse(array3[11]) - 1;
			ThemeChangerV4();
			change14 = int.Parse(array3[12]) - 1;
			ThemeChangerV5();
			change15 = int.Parse(array3[13]) - 1;
			ThemeChangerV6();
			change16 = int.Parse(array3[14]) - 1;
			ThemeChangerV7();
		}
		catch
		{
		}
		NotifiLib.SendNotification("<color=white>[</color><color=blue>LOAD</color><color=white>]</color> <color=white>Loaded settings successfully!</color>");
	}

	public static void PlatformsThing(bool invis, bool sticky)
	{
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_014a: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Expected O, but got Unknown
		//IL_0389: Unknown result type (might be due to invalid IL or missing references)
		//IL_039a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0271: Unknown result type (might be due to invalid IL or missing references)
		//IL_0295: Unknown result type (might be due to invalid IL or missing references)
		//IL_029f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0315: Unknown result type (might be due to invalid IL or missing references)
		//IL_031a: Unknown result type (might be due to invalid IL or missing references)
		//IL_032b: Expected O, but got Unknown
		if (TriggerPlats)
		{
			RPlat = WristMenu.triggerDownR;
			LPlat = WristMenu.triggerDownL;
		}
		else
		{
			RPlat = WristMenu.gripDownR;
			LPlat = WristMenu.gripDownL;
		}
		if (RPlat)
		{
			if (!once_right && (Object)(object)jump_right_local == (Object)null)
			{
				if (sticky)
				{
					jump_right_local = GameObject.CreatePrimitive((PrimitiveType)0);
				}
				else
				{
					jump_right_local = GameObject.CreatePrimitive((PrimitiveType)3);
				}
				if (invis)
				{
					Object.Destroy((Object)(object)jump_right_local.GetComponent<Renderer>());
				}
				jump_right_local.transform.localScale = scale;
				jump_right_local.transform.position = new Vector3(0f, -0.01f, 0f) + GTPlayer.Instance.RightHand.controllerTransform.position;
				jump_right_local.transform.rotation = GTPlayer.Instance.RightHand.controllerTransform.rotation;
				jump_right_local.AddComponent<GorillaSurfaceOverride>().overrideIndex = jump_right_local.GetComponent<GorillaSurfaceOverride>().overrideIndex;
				once_right = true;
				once_right_false = false;
				ColorChanger colorChanger = jump_right_local.AddComponent<ColorChanger>();
				colorChanger.colors = new Gradient
				{
					colorKeys = colorKeysPlatformMonke
				};
				colorChanger.Start();
			}
		}
		else if (!once_right_false && (Object)(object)jump_right_local != (Object)null)
		{
			Object.Destroy((Object)(object)jump_right_local.GetComponent<Collider>());
			Component obj = jump_right_local.AddComponent(typeof(Rigidbody));
			Rigidbody val = (Rigidbody)(object)((obj is Rigidbody) ? obj : null);
			val.linearVelocity = GTPlayer.Instance.RightHand.velocityTracker.GetAverageVelocity(true, 5f, false);
			Object.Destroy((Object)(object)jump_right_local, 2f);
			jump_right_local = null;
			once_right = false;
			once_right_false = true;
		}
		if (LPlat)
		{
			if (!once_left && (Object)(object)jump_left_local == (Object)null)
			{
				if (sticky)
				{
					jump_left_local = GameObject.CreatePrimitive((PrimitiveType)0);
				}
				else
				{
					jump_left_local = GameObject.CreatePrimitive((PrimitiveType)3);
				}
				if (invis)
				{
					Object.Destroy((Object)(object)jump_left_local.GetComponent<Renderer>());
				}
				jump_left_local.transform.localScale = scale;
				jump_left_local.transform.position = new Vector3(0f, -0.01f, 0f) + GTPlayer.Instance.LeftHand.controllerTransform.position;
				jump_left_local.transform.rotation = GTPlayer.Instance.LeftHand.controllerTransform.rotation;
				jump_left_local.AddComponent<GorillaSurfaceOverride>().overrideIndex = jump_left_local.GetComponent<GorillaSurfaceOverride>().overrideIndex;
				once_left = true;
				once_left_false = false;
				ColorChanger colorChanger2 = jump_left_local.AddComponent<ColorChanger>();
				colorChanger2.colors = new Gradient
				{
					colorKeys = colorKeysPlatformMonke
				};
				colorChanger2.Start();
			}
		}
		else if (!once_left_false && (Object)(object)jump_left_local != (Object)null)
		{
			Object.Destroy((Object)(object)jump_left_local.GetComponent<Collider>());
			Component obj2 = jump_left_local.AddComponent(typeof(Rigidbody));
			Rigidbody val2 = (Rigidbody)(object)((obj2 is Rigidbody) ? obj2 : null);
			val2.linearVelocity = GTPlayer.Instance.LeftHand.velocityTracker.GetAverageVelocity(true, 5f, false);
			Object.Destroy((Object)(object)jump_left_local, 2f);
			jump_left_local = null;
			once_left = false;
			once_left_false = true;
		}
	}

	public static ButtonInfo GetButton(string name)
	{
		foreach (ButtonInfo button in WristMenu.buttons)
		{
			if (button.buttonText == name)
			{
				return button;
			}
		}
		foreach (ButtonInfo settingsbutton in WristMenu.settingsbuttons)
		{
			if (settingsbutton.buttonText == name)
			{
				return settingsbutton;
			}
		}
		foreach (ButtonInfo item in WristMenu.CatButtons1)
		{
			if (item.buttonText == name)
			{
				return item;
			}
		}
		foreach (ButtonInfo item2 in WristMenu.CatButtons2)
		{
			if (item2.buttonText == name)
			{
				return item2;
			}
		}
		foreach (ButtonInfo item3 in WristMenu.CatButtons3)
		{
			if (item3.buttonText == name)
			{
				return item3;
			}
		}
		foreach (ButtonInfo item4 in WristMenu.CatButtons4)
		{
			if (item4.buttonText == name)
			{
				return item4;
			}
		}
		foreach (ButtonInfo item5 in WristMenu.CatButtons5)
		{
			if (item5.buttonText == name)
			{
				return item5;
			}
		}
		foreach (ButtonInfo item6 in WristMenu.CatButtons6)
		{
			if (item6.buttonText == name)
			{
				return item6;
			}
		}
		foreach (ButtonInfo item7 in WristMenu.CatButtons7)
		{
			if (item7.buttonText == name)
			{
				return item7;
			}
		}
		foreach (ButtonInfo item8 in WristMenu.CatButtons8)
		{
			if (item8.buttonText == name)
			{
				return item8;
			}
		}
		foreach (ButtonInfo item9 in WristMenu.CatButtons9)
		{
			if (item9.buttonText == name)
			{
				return item9;
			}
		}
		foreach (ButtonInfo item10 in WristMenu.CatButtons10)
		{
			if (item10.buttonText == name)
			{
				return item10;
			}
		}
		return null;
	}

	public static void Settings()
	{
		WristMenu.settingsbuttons[0].enabled = false;
		WristMenu.buttons[2].enabled = false;
		inSettings = !inSettings;
		if (inSettings)
		{
			WristMenu.pageNumber = 0;
		}
		if (!inSettings)
		{
			WristMenu.pageNumber = 0;
		}
		WristMenu.DestroyMenu();
		WristMenu.instance.Draw();
	}

	public static void Cat1()
	{
		WristMenu.CatButtons1[0].enabled = false;
		WristMenu.buttons[3].enabled = false;
		inCat1 = !inCat1;
		if (inCat1)
		{
			WristMenu.pageNumber = 0;
		}
		if (change7 == 1 && !inCat1)
		{
			WristMenu.pageNumber = 1;
		}
		if (((change7 == 2) | (change7 == 3) | (change7 == 4) | (change7 == 5)) && !inCat1)
		{
			WristMenu.pageNumber = 0;
		}
		WristMenu.DestroyMenu();
		WristMenu.instance.Draw();
	}

	public static void Cat2()
	{
		WristMenu.CatButtons2[0].enabled = false;
		WristMenu.buttons[4].enabled = false;
		inCat2 = !inCat2;
		if (inCat2)
		{
			WristMenu.pageNumber = 0;
		}
		if (change7 == 1 && !inCat2)
		{
			WristMenu.pageNumber = 1;
		}
		if (((change7 == 2) | (change7 == 3) | (change7 == 4) | (change7 == 5)) && !inCat2)
		{
			WristMenu.pageNumber = 0;
		}
		WristMenu.DestroyMenu();
		WristMenu.instance.Draw();
	}

	public static void Cat3()
	{
		WristMenu.CatButtons3[0].enabled = false;
		WristMenu.buttons[5].enabled = false;
		inCat3 = !inCat3;
		if (inCat3)
		{
			WristMenu.pageNumber = 0;
		}
		if (change7 == 1 && !inCat3)
		{
			WristMenu.pageNumber = 1;
		}
		if (((change7 == 2) | (change7 == 3) | (change7 == 4) | (change7 == 5)) && !inCat3)
		{
			WristMenu.pageNumber = 1;
		}
		WristMenu.DestroyMenu();
		WristMenu.instance.Draw();
	}

	public static void Cat4()
	{
		WristMenu.CatButtons4[0].enabled = false;
		WristMenu.buttons[6].enabled = false;
		inCat4 = !inCat4;
		if (inCat4)
		{
			WristMenu.pageNumber = 0;
		}
		if (change7 == 1 && !inCat4)
		{
			WristMenu.pageNumber = 1;
		}
		if (((change7 == 2) | (change7 == 3) | (change7 == 4) | (change7 == 5)) && !inCat4)
		{
			WristMenu.pageNumber = 1;
		}
		WristMenu.DestroyMenu();
		WristMenu.instance.Draw();
	}

	public static void Cat5()
	{
		WristMenu.CatButtons5[0].enabled = false;
		WristMenu.buttons[7].enabled = false;
		inCat5 = !inCat5;
		if (inCat5)
		{
			WristMenu.pageNumber = 0;
		}
		if (change7 == 1 && !inCat5)
		{
			WristMenu.pageNumber = 2;
		}
		if (((change7 == 2) | (change7 == 3) | (change7 == 4) | (change7 == 5)) && !inCat5)
		{
			WristMenu.pageNumber = 1;
		}
		WristMenu.DestroyMenu();
		WristMenu.instance.Draw();
	}

	public static void Cat6()
	{
		WristMenu.CatButtons6[0].enabled = false;
		WristMenu.buttons[8].enabled = false;
		inCat6 = !inCat6;
		if (inCat6)
		{
			WristMenu.pageNumber = 0;
		}
		if (change7 == 1 && !inCat6)
		{
			WristMenu.pageNumber = 2;
		}
		if (((change7 == 2) | (change7 == 3) | (change7 == 4) | (change7 == 5)) && !inCat6)
		{
			WristMenu.pageNumber = 1;
		}
		WristMenu.DestroyMenu();
		WristMenu.instance.Draw();
	}

	public static void Cat7()
	{
		WristMenu.CatButtons7[0].enabled = false;
		WristMenu.buttons[9].enabled = false;
		inCat7 = !inCat7;
		if (inCat7)
		{
			WristMenu.pageNumber = 0;
		}
		if (change7 == 1 && !inCat7)
		{
			WristMenu.pageNumber = 2;
		}
		if (((change7 == 2) | (change7 == 3) | (change7 == 4) | (change7 == 5)) && !inCat7)
		{
			WristMenu.pageNumber = 1;
		}
		WristMenu.DestroyMenu();
		WristMenu.instance.Draw();
	}

	public static void Cat8()
	{
		WristMenu.CatButtons8[0].enabled = false;
		WristMenu.buttons[10].enabled = false;
		inCat8 = !inCat8;
		if (inCat8)
		{
			WristMenu.pageNumber = 0;
		}
		if (change7 == 1 && !inCat8)
		{
			WristMenu.pageNumber = 2;
		}
		if (((change7 == 2) | (change7 == 3) | (change7 == 4) | (change7 == 5)) && !inCat8)
		{
			WristMenu.pageNumber = 1;
		}
		WristMenu.DestroyMenu();
		WristMenu.instance.Draw();
	}

	public static void Cat9()
	{
		WristMenu.CatButtons9[0].enabled = false;
		WristMenu.buttons[11].enabled = false;
		inCat9 = !inCat9;
		if (inCat9)
		{
			WristMenu.pageNumber = 0;
		}
		if (change7 == 1 && !inCat9)
		{
			WristMenu.pageNumber = 2;
		}
		if (((change7 == 2) | (change7 == 3) | (change7 == 4) | (change7 == 5)) && !inCat9)
		{
			WristMenu.pageNumber = 2;
		}
		WristMenu.DestroyMenu();
		WristMenu.instance.Draw();
	}

	public static void Cat10()
	{
		WristMenu.CatButtons10[0].enabled = false;
		WristMenu.buttons[12].enabled = false;
		inCat10 = !inCat10;
		if (inCat10)
		{
			WristMenu.pageNumber = 0;
		}
		if (change7 == 1 && !inCat10)
		{
			WristMenu.pageNumber = 3;
		}
		if (((change7 == 2) | (change7 == 3) | (change7 == 4) | (change7 == 5)) && !inCat10)
		{
			WristMenu.pageNumber = 2;
		}
		WristMenu.DestroyMenu();
		WristMenu.instance.Draw();
	}

	public static void Cat11()
	{
		WristMenu.CatButtons11[0].enabled = false;
		WristMenu.buttons[13].enabled = false;
		inCat11 = !inCat11;
		if (inCat11)
		{
			WristMenu.pageNumber = 0;
		}
		else
		{
			WristMenu.pageNumber = 0;
		}
		WristMenu.DestroyMenu();
		WristMenu.instance.Draw();
	}

	public static void Changeplat()
	{
		change1++;
		if (change1 > 2)
		{
			change1 = 1;
		}
		if (change1 == 1)
		{
			TriggerPlats = false;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>PLATFORMS</color><color=white>] Enable Platforms: Grips</color>");
		}
		if (change1 == 2)
		{
			TriggerPlats = true;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>PLATFORMS</color><color=white>] Enable Platforms: Triggers</color>");
		}
	}

	public static void Changenoti()
	{
		change2++;
		if (change2 > 2)
		{
			change2 = 1;
		}
		if (change2 == 1)
		{
			NotifiLib.IsEnabled = true;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>NOTIS</color><color=white>] Notis Enabled: Yes</color>");
		}
		if (change2 == 2)
		{
			NotifiLib.SendNotification("<color=white>[</color><color=blue>NOTIS</color><color=white>] Notis Enabled: No</color>");
			NotifiLib.IsEnabled = false;
		}
	}

	public static void ChangeFPS()
	{
		change3++;
		if (change3 > 2)
		{
			change3 = 1;
		}
		if (change3 == 1)
		{
			FPSPage = false;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>FPS & PAGE COUNTER</color><color=white>] Is Enabled: No</color>");
		}
		if (change3 == 2)
		{
			FPSPage = true;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>FPS & PAGE COUNTER</color><color=white>] Is Enabled: Yes</color>");
		}
	}

	public static void Changedisconnect()
	{
		change4++;
		if (change4 > 4)
		{
			change4 = 1;
		}
		if (change4 == 1)
		{
			NotifiLib.SendNotification("<color=white>[</color><color=blue>DISCONNECT BUTTON</color><color=white>] Disconnect Location: Right Side</color>");
		}
		if (change4 == 2)
		{
			NotifiLib.SendNotification("<color=white>[</color><color=blue>DISCONNECT BUTTON</color><color=white>] Disconnect Location: Left Side</color>");
		}
		if (change4 == 3)
		{
			NotifiLib.SendNotification("<color=white>[</color><color=blue>DISCONNECT BUTTON</color><color=white>] Disconnect Location: Top</color>");
		}
		if (change4 == 4)
		{
			NotifiLib.SendNotification("<color=white>[</color><color=blue>DISCONNECT BUTTON</color><color=white>] Disconnect Location: Bottom</color>");
		}
	}

	public static void Changemenu()
	{
		change6++;
		if (change6 > 2)
		{
			change6 = 1;
		}
		if (change6 == 1)
		{
			right = false;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>MENU LOCATION</color><color=white>] Current Location: Left Hand</color>");
		}
		if (change6 == 2)
		{
			right = true;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>MENU LOCATION</color><color=white>] Current Location: Right Hand</color>");
		}
	}

	public static void Changepagebutton()
	{
		change7++;
		if (change7 > 5)
		{
			change7 = 1;
		}
		if (change7 == 1)
		{
			NotifiLib.SendNotification("<color=white>[</color><color=blue>NEXT & PREV</color><color=white>] Page Change Button Location: On Menu</color>");
		}
		if (change7 == 2)
		{
			NotifiLib.SendNotification("<color=white>[</color><color=blue>NEXT & PREV</color><color=white>] Page Change Button Location: Top</color>");
		}
		if (change7 == 3)
		{
			NotifiLib.SendNotification("<color=white>[</color><color=blue>NEXT & PREV</color><color=white>] Page Change Button Location: Sides</color>");
		}
		if (change7 == 4)
		{
			NotifiLib.SendNotification("<color=white>[</color><color=blue>NEXT & PREV</color><color=white>] Page Change Button Location: Bottom</color>");
		}
		if (change7 == 5)
		{
			NotifiLib.SendNotification("<color=white>[</color><color=blue>NEXT & PREV</color><color=white>] Page Change Button Location: Triggers</color>");
		}
	}

	public static void ChangeOrbColor()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		change8++;
		if (change8 > 9)
		{
			change8 = 1;
		}
		if (change8 == 1)
		{
			CurrentGunColor = Color.blue;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN COLOR</color><color=white>] Current Color: Blue</color>");
		}
		if (change8 == 2)
		{
			CurrentGunColor = Color.red;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN COLOR</color><color=white>] Current Color: Red</color>");
		}
		if (change8 == 3)
		{
			CurrentGunColor = Color.white;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN COLOR</color><color=white>] Current Color: White</color>");
		}
		if (change8 == 4)
		{
			CurrentGunColor = Color.green;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN COLOR</color><color=white>] Current Color: Green</color>");
		}
		if (change8 == 5)
		{
			CurrentGunColor = Color.magenta;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN COLOR</color><color=white>] Current Color: Magenta</color>");
		}
		if (change8 == 6)
		{
			CurrentGunColor = Color.cyan;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN COLOR</color><color=white>] Current Color: Cyan</color>");
		}
		if (change8 == 7)
		{
			CurrentGunColor = Color.yellow;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN COLOR</color><color=white>] Current Color: Yellow</color>");
		}
		if (change8 == 8)
		{
			CurrentGunColor = Color.black;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN COLOR</color><color=white>] Current Color: Black</color>");
		}
		if (change8 == 9)
		{
			CurrentGunColor = Color.grey;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>GUN COLOR</color><color=white>] Current Color: Grey</color>");
		}
	}

	public static void ChangeVisualColor()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		change9++;
		if (change9 > 9)
		{
			change9 = 1;
		}
		if (change9 == 1)
		{
			CurrentESPColor = Color.blue;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: Blue</color>");
		}
		if (change9 == 2)
		{
			CurrentESPColor = Color.red;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: Red</color>");
		}
		if (change9 == 3)
		{
			CurrentESPColor = Color.white;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: White</color>");
		}
		if (change9 == 4)
		{
			CurrentESPColor = Color.green;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: Green</color>");
		}
		if (change9 == 5)
		{
			CurrentESPColor = Color.magenta;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: Magenta</color>");
		}
		if (change9 == 6)
		{
			CurrentESPColor = Color.cyan;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: Cyan</color>");
		}
		if (change9 == 7)
		{
			CurrentESPColor = Color.yellow;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: Yellow</color>");
		}
		if (change9 == 8)
		{
			CurrentESPColor = Color.black;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: Black</color>");
		}
		if (change9 == 9)
		{
			CurrentESPColor = Color.grey;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>ESP COLOR</color><color=white>] Current Color: Grey</color>");
		}
	}

	public static void ThemeChangerV1()
	{
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0223: Unknown result type (might be due to invalid IL or missing references)
		//IL_0205: Unknown result type (might be due to invalid IL or missing references)
		//IL_020a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0250: Unknown result type (might be due to invalid IL or missing references)
		//IL_0255: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		change10++;
		if (change10 > 11)
		{
			change10 = 1;
		}
		if (change10 == 1)
		{
			if (WristMenu.ChangingColors)
			{
				RGBMenu = false;
				WristMenu.FirstColor1 = Color.blue;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: Blue</color>");
			}
			else
			{
				RGBMenu = false;
				WristMenu.NormalColor = Color.blue;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Blue</color>");
			}
		}
		if (change10 == 2)
		{
			if (WristMenu.ChangingColors)
			{
				WristMenu.FirstColor1 = Color.red;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: Red</color>");
			}
			else
			{
				WristMenu.NormalColor = Color.red;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Red</color>");
			}
		}
		if (change10 == 3)
		{
			if (WristMenu.ChangingColors)
			{
				WristMenu.FirstColor1 = Color.white;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: White</color>");
			}
			else
			{
				WristMenu.NormalColor = Color.white;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: White</color>");
			}
		}
		if (change10 == 4)
		{
			if (WristMenu.ChangingColors)
			{
				WristMenu.FirstColor1 = Color.green;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: Green</color>");
			}
			else
			{
				WristMenu.NormalColor = Color.green;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Green</color>");
			}
		}
		if (change10 == 5)
		{
			if (WristMenu.ChangingColors)
			{
				WristMenu.FirstColor1 = Color.magenta;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: Magenta</color>");
			}
			else
			{
				WristMenu.NormalColor = Color.magenta;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Magenta</color>");
			}
		}
		if (change10 == 6)
		{
			if (WristMenu.ChangingColors)
			{
				WristMenu.FirstColor1 = Color.cyan;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: Cyan</color>");
			}
			else
			{
				WristMenu.NormalColor = Color.cyan;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Cyan</color>");
			}
		}
		if (change10 == 7)
		{
			if (WristMenu.ChangingColors)
			{
				WristMenu.FirstColor1 = Color.yellow;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: Yellow</color>");
			}
			else
			{
				WristMenu.NormalColor = Color.yellow;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Yellow</color>");
			}
		}
		if (change10 == 8)
		{
			if (WristMenu.ChangingColors)
			{
				WristMenu.FirstColor1 = Color.black;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: Black</color>");
			}
			else
			{
				WristMenu.NormalColor = Color.black;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Black</color>");
			}
		}
		if (change10 == 9)
		{
			if (WristMenu.ChangingColors)
			{
				WristMenu.FirstColor1 = Color.grey;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] First Color: Grey</color>");
			}
			else
			{
				WristMenu.NormalColor = Color.grey;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Grey</color>");
			}
		}
		if (change10 == 10)
		{
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: Clear</color>");
		}
		if (change10 == 11)
		{
			if (WristMenu.ChangingColors)
			{
				RGBMenu = true;
				NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Menu Color: RGB</color>");
			}
			else
			{
				NotifiLib.SendNotification("<color=white>[</color><color=red>ERROR</color><color=white>] Cannot Change The Menu To RGB Due To WristMenu.ChangingColors Being false</color>");
			}
		}
	}

	public static void ThemeChangerV2()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		change11++;
		if (change11 > 9)
		{
			change11 = 1;
		}
		if (change11 == 1)
		{
			WristMenu.SecondColor = Color.black;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: Black</color>");
		}
		if (change11 == 2)
		{
			WristMenu.SecondColor = Color.red;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: Red</color>");
		}
		if (change11 == 3)
		{
			WristMenu.SecondColor = Color.white;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: White</color>");
		}
		if (change11 == 4)
		{
			WristMenu.SecondColor = Color.green;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: Green</color>");
		}
		if (change11 == 5)
		{
			WristMenu.SecondColor = Color.magenta;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: Magenta</color>");
		}
		if (change11 == 6)
		{
			WristMenu.SecondColor = Color.cyan;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: Cyan</color>");
		}
		if (change11 == 7)
		{
			WristMenu.SecondColor = Color.yellow;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: Yellow</color>");
		}
		if (change11 == 8)
		{
			WristMenu.SecondColor = Color.blue;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: Blue</color>");
		}
		if (change11 == 9)
		{
			WristMenu.SecondColor = Color.grey;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Second Color: Grey</color>");
		}
	}

	public static void ThemeChangerV3()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		change12++;
		if (change12 > 10)
		{
			change12 = 1;
		}
		if (change12 == 1)
		{
			WristMenu.ButtonColorDisable = Color.yellow;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Yellow</color>");
		}
		if (change12 == 2)
		{
			WristMenu.ButtonColorDisable = Color.red;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Red</color>");
		}
		if (change12 == 3)
		{
			WristMenu.ButtonColorDisable = Color.white;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: White</color>");
		}
		if (change12 == 4)
		{
			WristMenu.ButtonColorDisable = Color.green;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Green</color>");
		}
		if (change12 == 5)
		{
			WristMenu.ButtonColorDisable = Color.magenta;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Magenta</color>");
		}
		if (change12 == 6)
		{
			WristMenu.ButtonColorDisable = Color.cyan;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Cyan</color>");
		}
		if (change12 == 7)
		{
			WristMenu.ButtonColorDisable = Color.black;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Black</color>");
		}
		if (change12 == 8)
		{
			WristMenu.ButtonColorDisable = Color.blue;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Blue</color>");
		}
		if (change12 == 9)
		{
			WristMenu.ButtonColorDisable = Color.grey;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Grey</color>");
		}
		if (change12 == 10)
		{
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disable Button Color: Clear</color>");
		}
	}

	public static void ThemeChangerV4()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		change13++;
		if (change13 > 10)
		{
			change13 = 1;
		}
		if (change13 == 1)
		{
			WristMenu.ButtonColorEnabled = Color.magenta;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Magenta</color>");
		}
		if (change13 == 2)
		{
			WristMenu.ButtonColorEnabled = Color.red;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Red</color>");
		}
		if (change13 == 3)
		{
			WristMenu.ButtonColorEnabled = Color.white;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: White</color>");
		}
		if (change13 == 4)
		{
			WristMenu.ButtonColorEnabled = Color.green;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Green</color>");
		}
		if (change13 == 5)
		{
			WristMenu.ButtonColorEnabled = Color.yellow;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Yellow</color>");
		}
		if (change13 == 6)
		{
			WristMenu.ButtonColorEnabled = Color.cyan;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Cyan</color>");
		}
		if (change13 == 7)
		{
			WristMenu.ButtonColorEnabled = Color.black;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Black</color>");
		}
		if (change13 == 8)
		{
			WristMenu.ButtonColorEnabled = Color.blue;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Blue</color>");
		}
		if (change13 == 9)
		{
			WristMenu.ButtonColorEnabled = Color.grey;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Grey</color>");
		}
		if (change13 == 10)
		{
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enable Button Color: Clear</color>");
		}
	}

	public static void ThemeChangerV5()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		change14++;
		if (change14 > 9)
		{
			change14 = 1;
		}
		if (change14 == 1)
		{
			WristMenu.EnableTextColor = Color.black;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: Black</color>");
		}
		if (change14 == 2)
		{
			WristMenu.EnableTextColor = Color.red;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: Red</color>");
		}
		if (change14 == 3)
		{
			WristMenu.EnableTextColor = Color.white;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: White</color>");
		}
		if (change14 == 4)
		{
			WristMenu.EnableTextColor = Color.green;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: Green</color>");
		}
		if (change14 == 5)
		{
			WristMenu.EnableTextColor = Color.yellow;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: Yellow</color>");
		}
		if (change14 == 6)
		{
			WristMenu.EnableTextColor = Color.cyan;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: Cyan</color>");
		}
		if (change14 == 7)
		{
			WristMenu.EnableTextColor = Color.magenta;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: Magenta</color>");
		}
		if (change14 == 8)
		{
			WristMenu.EnableTextColor = Color.blue;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: Blue</color>");
		}
		if (change14 == 9)
		{
			WristMenu.EnableTextColor = Color.grey;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Enabled Text Color: Grey</color>");
		}
	}

	public static void ThemeChangerV6()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0159: Unknown result type (might be due to invalid IL or missing references)
		change15++;
		if (change15 > 9)
		{
			change15 = 1;
		}
		if (change15 == 1)
		{
			WristMenu.DIsableTextColor = Color.black;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: Black</color>");
		}
		if (change15 == 2)
		{
			WristMenu.DIsableTextColor = Color.red;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: Red</color>");
		}
		if (change15 == 3)
		{
			WristMenu.DIsableTextColor = Color.white;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: White</color>");
		}
		if (change15 == 4)
		{
			WristMenu.DIsableTextColor = Color.green;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: Green</color>");
		}
		if (change15 == 5)
		{
			WristMenu.DIsableTextColor = Color.yellow;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: Yellow</color>");
		}
		if (change15 == 6)
		{
			WristMenu.DIsableTextColor = Color.cyan;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: Cyan</color>");
		}
		if (change15 == 7)
		{
			WristMenu.DIsableTextColor = Color.magenta;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: Magenta</color>");
		}
		if (change15 == 8)
		{
			WristMenu.DIsableTextColor = Color.blue;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: Blue</color>");
		}
		if (change15 == 9)
		{
			WristMenu.DIsableTextColor = Color.grey;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Disabled Text Color: Grey</color>");
		}
	}

	public static void ThemeChangerV7()
	{
		change16++;
		if (change16 > 6)
		{
			change16 = 1;
		}
		if (change16 == 1)
		{
			ButtonSound = 67;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Button Sound: Normal</color>");
		}
		if (change16 == 2)
		{
			ButtonSound = 8;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Button Sound: Stump</color>");
		}
		if (change16 == 3)
		{
			ButtonSound = 203;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Button Sound: AK47</color>");
		}
		if (change16 == 4)
		{
			ButtonSound = 50;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Button Sound: Glass</color>");
		}
		if (change16 == 5)
		{
			ButtonSound = 66;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Button Sound: KeyBoard</color>");
		}
		if (change16 == 6)
		{
			ButtonSound = 114;
			NotifiLib.SendNotification("<color=white>[</color><color=blue>THEME CHANGER</color><color=white>] Button Sound: Cayon Bridge</color>");
		}
	}

	public static void ChangeProj()
	{
		projint++;
		if (projint > d.Keys.Count - 1)
		{
			projint = 0;
		}
		curprojb = d.Keys.ToList()[projint];
		NotifiLib.SendNotification("<color=white>[</color><color=blue>PROJECTILE</color><color=white>] Current Projectile: " + curprojb + "</color>");
	}
}
