using GorillaNetworking;
using HarmonyLib;
using Photon.Pun;

namespace MalachiTemp.Utilities;

[HarmonyPatch(typeof(GorillaComputer), "UpdateScreen")]
internal class GorillaComputerScreenPatch
{
	private static void Postfix(GorillaComputer __instance)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Invalid comparison between Unknown and I4
		string text = PhotonNetwork.CountOfPlayers.ToString();
		string text2 = PhotonNetwork.CountOfRooms.ToString();
		string text3 = PhotonNetwork.GetPing().ToString();
		if ((int)__instance.currentState == 0)
		{
			__instance.screenText.Set("<color=purple>Nebula OS</color>\n\nPlayers Online Gorilla Tag: " + text + "\nRooms: " + text2 + "\nPing: " + text3 + " ms\nMenu Status: Undetected\nPress any key to start.\nThanks for using Nebula Client! Hold Y to open the menu. This menu is made by MDG!");
		}
	}
}
