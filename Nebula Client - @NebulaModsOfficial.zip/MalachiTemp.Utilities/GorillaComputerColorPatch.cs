using System;
using System.Collections.Generic;
using GorillaNetworking;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace MalachiTemp.Utilities;

[HarmonyPatch(typeof(GorillaComputer))]
internal static class GorillaComputerColorPatch
{
	private static bool _added;

	[HarmonyPatch(typeof(GorillaComputer), "Awake")]
	[HarmonyPostfix]
	private static void AwakePostfix(GorillaComputer __instance)
	{
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Expected O, but got Unknown
		if (!_added && !__instance.OrderList.Exists((StateOrderItem item) => (int)item.State == 1))
		{
			int num = __instance.OrderList.FindIndex((StateOrderItem item) => (int)item.State == 2);
			if (num >= 0)
			{
				__instance.OrderList.Insert(num + 1, new StateOrderItem((ComputerState)1, "UTILITY"));
				_added = true;
			}
		}
	}

	[HarmonyPatch("UpdateScreen")]
	[HarmonyPostfix]
	private static void UpdateScreenPostfix(GorillaComputer __instance)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Invalid comparison between Unknown and I4
		if ((int)__instance.currentState == 1)
		{
			__instance.screenText.Set(Render(__instance));
		}
	}

	public static string Render(GorillaComputer __instance)
	{
		string text = PhotonNetwork.CountOfPlayers.ToString();
		string text2 = PhotonNetwork.CountOfRooms.ToString();
		string text3 = PhotonNetwork.GetPing().ToString();
		string text4 = Mathf.Round(1f / Time.unscaledDeltaTime).ToString();
		string text5 = (PhotonNetwork.InRoom ? PhotonNetwork.CurrentRoom.Name : "Not in a Room");
		string userId = PhotonNetwork.LocalPlayer.UserId;
		string nickName = PhotonNetwork.LocalPlayer.NickName;
		string text6 = (PhotonNetwork.InRoom ? PhotonNetwork.CurrentRoom.PlayerCount.ToString() : "Not in a Room");
		string text7 = "Not in a Room";
		if (PhotonNetwork.InRoom && ((Dictionary<object, object>)(object)((RoomInfo)PhotonNetwork.CurrentRoom).CustomProperties).TryGetValue((object)"gameMode", out object value))
		{
			text7 = GetGameMode(value.ToString());
		}
		return "Players Online Gorilla Tag: " + text + "\nRooms: " + text2 + "\nCurrent Room: " + text5 + "\nGame Mode: " + text7 + "\nQueue: " + GetCurrentQueue() + "\nPlayer Count: " + text6 + "\nNickname: " + nickName + "\nUser ID: " + userId + "\nPing: " + text3 + "ms\nFPS: " + text4 + "\nCurrent Time: " + DateTime.Now.ToString("hh:mm:ss tt");
	}

	private static string GetGameMode(string raw)
	{
		if (string.IsNullOrEmpty(raw))
		{
			return "None";
		}
		string[] array = raw.Split(new char[1] { ';' });
		if (array.Length > 2 && !string.IsNullOrEmpty(array[2]))
		{
			return FormatGameMode(array[2]);
		}
		for (int num = array.Length - 1; num >= 0; num--)
		{
			if (!string.IsNullOrEmpty(array[num]))
			{
				return FormatGameMode(array[num]);
			}
		}
		return "Not in a Room";
	}

	public static string GetCurrentQueue()
	{
		if (!PhotonNetwork.InRoom)
		{
			return "Not in a Room";
		}
		if (((Dictionary<object, object>)(object)((RoomInfo)PhotonNetwork.CurrentRoom).CustomProperties).TryGetValue((object)"gameMode", out object value))
		{
			string[] array = value.ToString().Split(new char[1] { ';' });
			if (array.Length > 1 && !string.IsNullOrEmpty(array[1]))
			{
				return array[1] switch
				{
					"DEFAULT" => "Default", 
					"MINIGAMES" => "Minigames", 
					"COMP" => "Competitive", 
					_ => array[1], 
				};
			}
		}
		return "Not in a Room";
	}

	private static string FormatGameMode(string rawMode)
	{
		if (string.IsNullOrEmpty(rawMode))
		{
			return "Not in a Room";
		}
		return rawMode switch
		{
			"Infection" => "Infection", 
			"Casual" => "Casual", 
			"HuntDown" => "Hunt", 
			"Paintbrawl" => "Paintbrawl", 
			"Ambush" => "Ambush", 
			"FreezeTag" => "Freeze Tag", 
			"Ghost" => "Ghost", 
			"Custom" => "Custom", 
			"Guardian" => "Guardian", 
			"PropHunt" => "Prop Hunt", 
			"InfectionCompetitive" => "Competitive Infection", 
			"SuperInfect" => "Super Infection", 
			"SuperCasual" => "Super Casual", 
			_ => rawMode, 
		};
	}
}
